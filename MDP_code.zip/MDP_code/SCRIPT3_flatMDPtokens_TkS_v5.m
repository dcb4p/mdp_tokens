%flatMDPtokens_TkS_v2.m
%Hybrid tabular version of MDP model for the tokens task (TkS -1/-2/+1/+2)
%last edit: 04.28.2023

%based on flatMDPtokens_TkS_v2.m

%adapted for TkS (Craig and Hua data)

%updates 1.2023:
%%%% (1) changed TSCO to 4-6 not 4-7
%%%% (2) changed max number of tk to 12 to correspond to (1)
%%%% (3) added intertrial interval
%%%% (4) option to input optimized parameters (optimized using flatMDPtokens_paramOptim_v1.m with choice data from a monkey)
%%%% (x): maybe future to do- add multiple blocks to account for total tk/juice received?
%%%% (5): loop to run multiple gammas, saves each individually

clear

%Choose monkey:

monkey='Uno';
%monkey='Boom';
%monkey='Prima';
%monkey='Sparkles';
%monkey='AJacks';

%monkey='Blis';
%monkey='CardiB';

%Set gamma to fit MDP: gamma=0.95;

%gammaset=[0.8,0.85,0.9,0.925,0.95,0.99,0.999]; %set of gammas to run

gammaset=0.999;
CHOOSEMODEL=1;

for g_iter= 1:length(gammaset)
    
    clearvars -except g_iter gammaset monkey
    gamma=gammaset(g_iter)


    if strcmp(monkey,'Uno')

        %fname_MDP_params_2opt= strcat('MDP_params_fitDate_05_05_23_monkey_Uno_gamma_',num2str(gamma),'.mat'); %second round MDP after 2nd round of param optim
        %load(fname_MDP_params_2opt,'bestparams','CHOOSEMODEL')

        fname_MDP_params_2opt= strcat('MDP_params_fitDate_08_21_23_monkey_Uno_gamma_',num2str(gamma),'_MODEL_',num2str(CHOOSEMODEL),'.mat'); %second round MDP after 2nd round of param optim
        load(fname_MDP_params_2opt,'bestparams','CHOOSEMODEL')

        %fname_MDP_params_2opt= strcat('MDP_params_fitDate_09_12_23_monkey_Uno_gamma_',num2str(gamma),'_MODEL_1.mat'); %round of MDP with values not pinned at NObs=1
        %load(fname_MDP_params_2opt,'bestparams','CHOOSEMODEL')

        %fname_MDP_params_2opt= strcat('MDP_params_fitDate_09_21_23_monkey_Uno_gamma_',num2str(gamma),'_MODEL_1.mat'); %round of MDP with values not pinned at NObs=1 and STD set to single value in time to increase std at Nobs=1
        %load(fname_MDP_params_2opt,'bestparams','CHOOSEMODEL')

        load('04_21_23_monkey_Uno_DataForMDP.mat'); % with bounded learning rates (0,inf)

    elseif strcmp(monkey,'Boom')
        %load('MDP_params_fitDate_04_24_23_monkey_Boom.mat','bestparams','CHOOSEMODEL');
        fname_MDP_params_2opt= strcat('MDP_params_fitDate_06_12_23_monkey_Boom_gamma_',num2str(gamma),'.mat'); %second round MDP after 2nd round of param optim
        load(fname_MDP_params_2opt,'bestparams','fixedparams','CHOOSEMODEL')

        load('04_17_23_monkey_B_DataForMDP.mat'); %Boom

    elseif strcmp(monkey,'Prima')

        fname_MDP_params_2opt= strcat('MDP_params_fitDate_05_05_23_monkey_Prima_gamma_',num2str(gamma),'.mat'); %second round MDP after 2nd round of param optim
        load(fname_MDP_params_2opt,'bestparams','CHOOSEMODEL')

        %load('MDP_params_fitDate_05_01_23_monkey_Prima.mat','bestparams','CHOOSEMODEL');
        load('04_18_23_monkey_P_DataForMDP.mat')

    elseif strcmp(monkey,'Sparkles')

        %load('MDP_params_fitDate_04_24_23_monkey_Sparkles.mat','bestparams','CHOOSEMODEL');

        fname_MDP_params_2opt= strcat('MDP_params_fitDate_05_05_23_monkey_Sparkles_gamma_',num2str(gamma),'.mat'); %second round MDP after 2nd round of param optim
        load(fname_MDP_params_2opt,'bestparams','CHOOSEMODEL')

        load('04_19_23_monkey_S_DataForMDP.mat')

    elseif strcmp(monkey,'AJacks')

        %load('MDP_params_fitDate_05_03_23_monkey_AJacks.mat','bestparams','CHOOSEMODEL');
        fname_MDP_params_2opt= strcat('MDP_params_fitDate_05_05_23_monkey_AJacks_gamma_',num2str(gamma),'.mat'); %second round MDP after 2nd round of param optim
        load(fname_MDP_params_2opt,'bestparams','CHOOSEMODEL')

        load('05_03_23_monkey_AJacks_DataForMDP.mat')

    elseif strcmp(monkey,'Blis')
        
    elseif strcmp(monkey,'CardiB')
        
        
    end
    
    
    
    %% Getting scaled value distributions to get p(tk|vi,ai) and functions
    %From RW analysis of TkS data from monkeys: Uno, Boom, Prima, Sparkles
    %Fit parameters to adjust these value curves to optimize the transition probabilities for p(getting tk|choice)
    
    if CHOOSEMODEL==1
        
        k_compress=bestparams(1);
        
        if strcmp(monkey,'Boom')
            beta_all=fixedparams(1);
        else
            beta_all=bestparams(2);
        end
        
        for cue=1:4
            singleCueVals(:,:)=modelMeanCueValues_allFiles(:,cue,:);
            
            %Decide to use mean or median values (median less subj to outlier sessions). Note that this is the median value curve of mean value curves from each session:
            %mean_singleCueVals(cue,:)=mean(singleCueVals);
            mean_singleCueVals(cue,:)=median(singleCueVals);
            
            %Feature of this model: Compress all value curves with 1 free parameter:
            mean_singleCueVals(cue,:)=k_compress*mean_singleCueVals(cue,:);
            
            %set v(obs1) to 0 at obs 1:
            %mean_singleCueVals(cue,1)=0;

            stdev_singleCueVals(cue,:)=std(singleCueVals);

        end

        %added 8.21.23
        %meanStdev=mean(stdev_singleCueVals);

        %Option added 9.21.23 fix std to single value::
        meanStdev=mean(mean(stdev_singleCueVals));

        for cue=1:4
            stdev_singleCueVals(cue,:)=meanStdev;
        end

    elseif CHOOSEMODEL==2
        k_compress=bestparams(1);

        if strcmp(monkey,'Boom')
            beta_all=fixedparams(1);
        else
            beta_all=bestparams(2);
        end

        for cue=1:4
            singleCueVals(:,:)=modelMeanCueValues_allFiles(:,cue,:);

            %Decide to use mean or median values (median less subj to outlier sessions). Note that this is the median value curve of mean value curves from each session:
            %mean_singleCueVals(cue,:)=mean(singleCueVals);
            mean_singleCueVals(cue,:)=median(singleCueVals);

            %Feature of this model: Compress all value curves with 1 free parameter:
            mean_singleCueVals(cue,:)=k_compress*mean_singleCueVals(cue,:);

            %set v(obs1) to 0 at obs 1:
            mean_singleCueVals(cue,1)=0;

            stdev_singleCueVals(cue,:)=std(singleCueVals);
        end

        %fix std for all curves to the to mean std >>>>>>>>>> not changing across time
        meanStdev=mean(stdev_singleCueVals);
        for cue=1:4
            stdev_singleCueVals(cue,:)=mean(meanStdev);
        end


        if 0
            %option to plot vals
            colorcues={'r-o';'g-o';'b-o';'c-o'};
            for cue=1:4
                figure(1); set(gcf,'Color',[1 1 1])
                x=1:ntrialsPerCondition;

                color=colorcues(cue,:);
                shadedErrorBar(x,mean_singleCueVals(cue,:),stdev_singleCueVals(cue,:),{char(color),'markerfacecolor','k'},1); hold on
                xlim([1 ntrialsPerCondition])
                xlabel('trial in a condition')
                ylabel('mean cue value (derived from avg behavior across conditions, model fit 11')
                set(gca,'FontSize',14)
            end

        end


    end
    
    
    %% Create table of transition probabilities for the possible tabular states
    %(kind of like a transition model T(s,a,s')
    
    %~~~~~~~~~~~~~~State features:
    %current tk-
    %trials since cashout
    %trial epoch (fix, cue, outcome, cashout)
    %condition (set of cues)
    %number of times each condition has been seen
    %possible outcomes--(0/+1/+2/-1/-2)
    
    transitP=[];
    
    %max values for
    
    max_nCurrTokens=13; %(0 through 12 max tk )
    max_trialsSinceCashout=6; %(1 through 6)
    ntrialEpochs=10; % (1)fix, (2-7)condition/choice *6, (8)outcome, (9)cashout (10) intertrial interval
    max_nobs_conditions=18; %1 through 18 times a condition can be seen, but we will maybe sample this to reduce dimensionality if needed
    nPossibleChoices=3; %no choice yet/choice 1/choice2
    nPossibleOutcomes=6; %no outcome yet/0/+1/+2/-1/-2 (5 possible outcomes + none yet)
    nconditions=6;
    
    %most of the transitions are 0.0 because you can't get to many states from
    %other states... transp=1/6 from fixation to any of the 6 conditions and
    %then 0.75 or 0.25 or 0 for choice to outcome for particular choices of
    %0,1,or2 tokens, and then growing probability of a cashout trial from 4 to
    %7 trials.
    
    %later we can include aborts as actions at different task epoch points:
    transitP=zeros(max_nCurrTokens,max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions,nPossibleChoices, nPossibleOutcomes);
    
    
    %% Construct transition probability matrix
    %note that true transition probability to condition is not 1/6 except on the first trial, because all conditions are presented before repeating.
    
    %6 conditions, not all have the same possible outcomes, this is where we get the p=1/6 for condition and 0.75/0.25 probabilities in there based on choice:
    %6 conditions collapsed by side:
    % 1= 1 v 2   %possible outcomes: 1,0 // 2,0 (best= opt 2 in all other cases)
    % 2 = 1 v -1 %possible outcomes: 1,0 // -1,0 (best= opt 1 in all other cases)
    % 3 = 2 v -1 %possible outcomes: 2,0 // -1,0
    % 4 = 1 v -2 %possible outcomes: 1,0 // -2,0
    % 5 = 2 v -2 %possible outcomes: 2,0 // -2,0
    % 6 = -1 v -2 %possible outcomes: -1,0 // -2,0
    
    %in simple version w/ one kind of tk, conditions should have slightly different values once learned (based on best outcome):
    % Highest
    % Med
    % Highest
    % Med
    % Highest
    % Lowest
    
    
    %Trial epochs: (1)Fixation, (2) Condition/choice, (3)Outcome, (4)Cashout time
    %condition, choice, outcome don't affect fixation, aren't known yet at that time in the trial
    %outcome doesn't affect condition onset in the same way, isn't known yet.
    
    %Set transition probabilities from fixation to condition epoch, no choice or outcome yet:
    ptrans=1/6;
    transitP(:,:,2:7,:,1,1)=ptrans; %doesn't need to be inside loop, some extra states for choices & outcomes that don't need to be filled
    
    %transitP=zeros(max_nCurrWaterTokens, max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions,nPossibleChoices, nPossibleOutcomes);
    
    for cond=1:nconditions
        % conditions 1-6
        
        for nobs=1:max_nobs_conditions
            
            for choice=1:2
                % choice1 or choice2 (index 1 handled below at transitP)
                
                %we now have probability of choice based on condition and number of times observed too, so that can be pulled from those curves created above to affect choice behavior later on.
                
                %Here we want to bring in what the 2 options are to use *those* two mean values for calculating posterior probabilities for the 4 possible outcomes in addition to 0 tk
                
                % 1= 1 v 2   %possible outcomes: 1,0 // 2,0 (best= opt 2 in all other cases)
                % 2 = 1 v -1 %possible outcomes: 1,0 // -1,0 (best= opt 1 in all other cases)
                % 3 = 2 v -1 %possible outcomes: 2,0 // -1,0
                % 4 = 1 v -2 %possible outcomes: 1,0 // -2,0
                % 5 = 2 v -2 %possible outcomes: 2,0 // -2,0
                % 6 = -1 v -2
                
                conditionCueInfo= [1,2; ... %<<1 v 2 >>
                    1,3; ... %<<1 v -1>>
                    2,3;...  %<<2 v -1>>
                    1,4;...  %<<1 v -2>>
                    2,4;...  %<<2 v -2>>
                    3,4];    %<<-1 v -2>>
                
                choiceCue=conditionCueInfo(cond,choice);
                
                
                for otc=2:nPossibleOutcomes
                    %previously this is where 80/20 probabilities came in for each condition and were coded as a lookup table, independent of trial.
                    
                    %Now we have distributions of values and can ask: what is the probability that a state value comes from one of these 4 distributions?
                    %order: none, 0, +1, +2, -1, -2
%                     if nobs==1
%                         %nobs=1 is 0 obs, so everything is equally likely, but still 25% chance of no reward
%                         if otc==2
%                             ptrans=0.25;
%                         else
%                             ptrans=0.75/4;
%                         end
%                     else

                        %IF NOBS=1 COMMENTED OUT, NOT PINNING PROBABILITIES TO BE EQUAL AT NOBS1
                        if otc==2
                            %We still use 75/25 for 25% chance of no reward:
                            ptrans=0.25;
                            
                        else
                            %otc= 3,4,5,6  // +1, +2, -1, -2
                            
                            %Calculating 4 posterior probabilities for each outcome given mean v associated with choice:
                            %using Bayes rule, where x=1:4 possible outcomes
                            % p(tkx|v) = [p(v|tkx)* p(tkx)] / p(v)
                            %p(tkx)=0.25
                            %p(v)= total probability of observing v (mean v from curves for the chosen option)
                            %p(v)= p(v|tk1)*p(tk1) + p(v|tk2)*p(tk2) + p(v|tk2)*p(tk2) + p(v|tk4)*p(tk4)
                            %p(v|tkx)= p(v|mu,sigma) = normpdf(v,u,sigma) --> trapz
                            
                            %v=mean_singleCueVals(choiceCue-2,nobs); %3456
                            v=mean_singleCueVals(choiceCue,nobs);
                            
                            p_tkx=0.75; %prior is 0.75, assume monkey knows 75/25 rwd sched
                            
                            %p_tkx=0.75/4;
                            
                            cdf_tkx_given_v=[];
                            p_v_given_tkx=[];
                            for cueval=1:4
                                
                                %try different way, just using gaussian function, not integrating:
                                sigma=stdev_singleCueVals(cueval,nobs);
                                mu=mean_singleCueVals(cueval,nobs);
                                x=mean_singleCueVals(choiceCue,nobs);
                                p_v_given_tkx(cueval)= (1/(sigma*sqrt(2*pi)))*exp(-0.5*(((x-mu)/sigma).^2));
                                
                            end
                            
                            pv=sum(p_v_given_tkx);
                            
                            p_tkx_given_v= (p_v_given_tkx(otc-2)*p_tkx)/pv;
                            
                            ptrans=p_tkx_given_v; %transition probability to the four remaining possible outcomes: 2J/1J/2W/1W
                        end
                    %end
                    
                    transitP(:,:,cond+1,nobs,choice+1,otc)=ptrans; %this is set for each choice and condition info is also brought in above
                    %Note that with inspection, it seems 1J is more likely than 1W and 2W (slightly) even at nobs=max. Not sure why, but k=Nstdev being lower decreases it a bit.
                    
                    
                end
            end
        end
        
    end
    %otc=n/0/+1/+2/-1/-2
    %transitP=zeros(max_nCurrTokens,max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions,nPossibleChoices, nPossibleOutcomes);
    
    
    %Checking transition probabilities for +1 v +2 condition scaling factors:
    %Poster panel 09.06.2023:

    if 1
        outcome1=3;
        outcome2=4;
        outcome3=5;
        outcome4=6;

        choice=2;
        clearvars tmp; figure(1000);set(gcf,'Color',[1 1 1]);
        tmp(:,:)=transitP(1,1,2,:,choice+1,outcome1);plot(tmp,'r','LineWidth',2); hold on
        tmp(:,:)=transitP(1,1,2,:,choice+1,outcome2); plot(tmp,'g','LineWidth',2);
        tmp(:,:)=transitP(1,1,2,:,choice+1,outcome3); plot(tmp,'b','LineWidth',2);
        tmp(:,:)=transitP(1,1,2,:,choice+1,outcome4); plot(tmp,'c','LineWidth',2);

        xlabel('NObs'); ylabel('p(tk|condition,choice)'); set(gca,'FontSize',14)
        if choice==1
            legend({'choosing +1, getting +1','choosing+1, getting +2','choosing+1, getting -1','choosing+1, getting -2'})
        elseif choice ==2
            legend({'choosing +2, getting +1','choosing+2, getting +2','choosing+2, getting -1','choosing+2, getting -2'})
        end
        xlim([1 18])

    end
    
    % %% 3.6.2023: Test transition probabilities to produce CP:
    % %Use converged state space to get state values
    % %compute action values for choices based on the new transition probabilities for gaining tokens
    % %do this for each condition
    % %get max(action values) for each condition and trial
    % %compare this to choice probability
    % %fit kstdev and kcompress parameters to get these curves to best fit cp of monkey
    %
    % %use same code as previously used to calculate transition probabilities, only difference is we don't load the transition probabilities
    % %in that SS file, but the ones produced above this block.
    %
    % loadSS=1; %0=use current SS from fit in this file, 1= load SS
    % %option to load file instead:
    % if loadSS==1
    %  load('12_23_22_gamma_0.95_iter_100_stateSpace_TkS_v1_kcomp1_kstd2.5.mat','stateUtility')
    % end
    %
    % load('12_22_22_Uno_tkS_loss_RWfits_Model11.mat','pcorr_allFiles','mRT_allFiles','modelChoiceProb_allFiles','nsessions','allmparams')
    %
    % transitPTest=transitP;
    %
    % overlayCPWithBehavior=1;
    % ntk=4;
    % trialsSinceCashout=5;
    % dt=[];
    % d=[];
    % gamma=1; %NOTE, also fit this?
    %
    % for nobs=1:18
    %     for condition=1:6
    %
    %         %compute 2 action values at time of choice
    %         %pass through logistic func to get choice probability for that trial
    %         %update num tk based on choice and 80/20 probabilities
    %         %every 4-7 trials, cashout and reset tk to 0
    %
    %         %action values at time of choice:
    %
    %         for choice=1:2
    %             nfuturestates=5; %0/+1/+2+/-1/-2
    %             transitPsFutureStates(1,1:nfuturestates)=transitPTest(ntk,trialsSinceCashout,condition+1,nobs,choice+1, 2:nPossibleOutcomes);
    %             utilitiesFutureStates(1,1:nfuturestates)=[stateUtility(ntk,trialsSinceCashout,8,1), ... %0tk
    %                 stateUtility(ntk+1,trialsSinceCashout,8,1), ... % +1
    %                 stateUtility(ntk+2,trialsSinceCashout,8,1),... % +2
    %                 stateUtility(ntk-1,trialsSinceCashout,8,1),... % -1
    %                 stateUtility(ntk-2,trialsSinceCashout,8,1)]; % -2
    %             FEV_single_choice= gamma*(dot(transitPsFutureStates,utilitiesFutureStates));
    %             actionvalues(choice)=FEV_single_choice;
    %         end
    %         %actionvalues
    %
    %         if condition==1
    %             beta=beta2v1;
    %         else
    %             beta=mean(allmparams(:,1)); %mean beta across sessions from RW
    %         end
    %
    %         d = exp(beta*actionvalues)./sum(exp(beta*actionvalues));
    %         if condition==1
    %             dt(condition,nobs) = d(2);
    %         else
    %             dt(condition,nobs) = d(1); %choice prob for option 1
    %         end
    %     end
    %
    % end
    %
    % % plot cp across conditions:
    % figure(100)
    % set(gcf,'Color',[1 1 1])
    % condit6={'2v1','1v -1','2 v -1','1 v -2','2 v -2','-1 v -2'};
    % for c=1:6
    %     subplot(2,3,c)
    %     plot(dt(c,:),'b-','LineWidth',2); hold on
    %     %shadedErrorBar(1:nobs,meancp,stderrcp,{'k','markerfacecolor','k'}); hold on
    %     xlabel('nobs'); ylabel('cp')
    %     title(condit6(c))
    %     ylim([0.4 1.05])
    %          xticks([0, 5, 10, 15, 20])
    %          set(gca,'FontSize',12)
    % end
    %
    % if overlayCPWithBehavior==1
    %
    %     plotcol='r';
    %
    %
    %     for c= 1:6
    %
    %         pcorrSingleCondition(:,:)=pcorr_allFiles(:,c,:);
    %         mRTSingleCondition(:,:)=mRT_allFiles(:,c,:);
    %
    %         pcorr_mean=nanmean(pcorrSingleCondition);
    %         pcorr_mean(isnan(pcorr_mean))=[];
    %         pcorr_stderr=stderr(pcorrSingleCondition);
    %         pcorr_stderr(isnan(pcorr_stderr))=[];
    %
    %
    %         rt_mean=nanmean(mRTSingleCondition);
    %         rt_mean(isnan(rt_mean))=[];
    %         rt_stderr=stderr(mRTSingleCondition);
    %         rt_stderr(isnan(rt_stderr))=[];
    %
    %         figure(1)
    %         %avg performance
    %         set(gcf,'Color',[1 1 1])
    %         subplot(2,6,c)
    %         plot(1:length(pcorr_mean),pcorr_mean,'ko-','LineWidth',1.5); hold on
    %         errorbar(1:length(pcorr_mean),pcorr_mean,pcorr_stderr,'k')
    %         set(gca,'fontsize',14)
    %         xlabel('Trial')
    %         title(condit6(c))
    %         if c==1
    %             ylabel('Fraction larger opt chosen')
    %         end
    %         xlim([0 18]); ylim([0.4 1])
    %
    %         figure(100)
    %         subplot(2,3,c)
    %         plot(1:length(pcorr_mean),pcorr_mean,'ko-','LineWidth',1.5); hold on
    %         errorbar(1:length(pcorr_mean),pcorr_mean,pcorr_stderr,'k')
    %         set(gca,'fontsize',14)
    %         xlabel('Trial')
    %         title(condit6(c))
    %         if c==6
    %             legend('MDP','MonkeyData','')
    %         end
    %
    %         %avg reaction times
    %         figure(1)
    %         subplot(2,6,c+6)
    %         plot(1:length(rt_mean),rt_mean,'mo-','LineWidth',1.5); hold on
    %         errorbar(1:length(rt_mean),rt_mean,rt_stderr,'m')
    %         set(gca,'fontsize',14)
    %         xlabel('Trial')
    %         ylabel('Mean RT')
    %         sgtitle(strcat('TkS-PCorr & Mean RTs ',' (nSessions=',{' '},num2str(nsessions),')'))
    %         xlim([0 18])
    %         ylim([220 260])
    %         set(gca,'fontsize',14)
    %
    %         %Choice Probability as predicted by model:
    %         %better option happens to be the first in all cases:
    %
    %         if c==1
    %             betterOpt=2;
    %         else
    %             betterOpt=1;
    %         end
    %
    %         cp(:,:)=modelChoiceProb_allFiles(:,c,:,betterOpt);
    %         meanCP=nanmean(cp);
    %         stderrCP=stderr(cp);
    %         figure(1)
    %         %model choice probability overlayed
    %         set(gcf,'Color',[1 1 1])
    %         subplot(2,6,c)
    %         plot(1:length(meanCP),meanCP,'Color',plotcol,'LineStyle','-','Marker','o', ...
    %             'LineWidth',1.5); hold on
    %         errorbar(1:length(meanCP),meanCP,stderrCP,'Color',plotcol)
    %         if c==6
    %            legend('MonkeyData','','RWFit','')
    %         end
    %
    %
    %     end
    %
    % end
    
    
    
    
    
    %% Transitions to cash-out states:
    %transitP=zeros(max_nCurrWaterTokens,max_nCurrJuiceTokens,max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions, nPossibleChoices, nPossibleOutcomes);
    
    %Trials since cashout can be up to 6, (not 7! updated from last version)
    %When it's been 6 trials since cashout, p=1 to transition to cashout
    
    for t=1:max_trialsSinceCashout
        if t <= 3
            ptrans=0;
        elseif t==4
            %4 trials since last cashout
            ptrans=1/3;
        elseif t==5
            %6 trials since last cashout
            ptrans=0.5;
        elseif t==6
            %7 trials since last cashout
            ptrans=1.0;
        end
        transitP(:,t,9,:,:,:)=ptrans; %only set for all nobs even though some of these states aren't ever actually reached
    end
    
    
    
    
    %% Create table of rewards based on states (cashout trial/epoch is the only actually rewarding set of states, Tk not assumed to be rewards...
    % but will eventually lead to states with tk having value)
    
    rew=zeros(max_nCurrTokens,max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions);
    for r=1:max_nCurrTokens
        %when wr=1, no tokens, idx 1= 0 tk
        rew(r,4:6,9,:)= (r-1); %rewards during cash-out epoch only. juice rewards 1tk=1unit, water rewards 1tk=0.1 unit
    end
    
    
    %% Stepping thru possible states using for loops:
    % * note that some complexity is ommitted where noted
    
    stateUtility0=zeros(max_nCurrTokens, max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions);
    stateUtility=zeros(max_nCurrTokens, max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions);
    RMSE_stateUtility=[];
    choicepolicy=[];
    
    %gamma=0.7;
    %gamma=1.0; %for troubleshooting but need to use span to check for conv. not done here
    
    for iter=1:100
        iter
        tic
        
        %for cobs=1
        for cobs=1:max_nobs_conditions
            %num times a condition has been seen (idx1 = 0 times)
            
            for ww=1:max_nCurrTokens
                %0->12
                %number of current tokens
                for tsco=1:max_trialsSinceCashout
                    %1-6
                    
                    %excluding states that aren't ever reached: e.g. 1 trial since cashout, 12 tk:
                    %don't calculate these states, leave as 0? or should they be left in for fitting?
                    if (ww-1) > (tsco*2)
                        
                    else
                        
                        for cc=1:ntrialEpochs
                            %10 trial epochs: fixation, cue*6, outcome, cashout time, ITI
                            clearvars utilityFutureStates
                            if cc==1
                                %Fixation state
                                %just want immediate future states
                                %cobs here is 1??
                                IEV=rew(ww,tsco,cc,cobs);
                                
                                clearvars nfuturestates utilityFutureStates transitPFutureStates
                                nfuturestates= size(transitP(ww,tsco,2:7,cobs,1,1),3); % = number of task cue pair conditions
                                utilityFutureStates(1,1:nfuturestates)=stateUtility(ww,tsco,2:7,cobs);
                                transitPFutureStates(1,1:nfuturestates)=transitP(ww,tsco,2:7,cobs,1,1); %1/6 for 6 conditions, note choice and outcome are dummy vars here, ie 1
                                
                                FEV=gamma*(dot(transitPFutureStates,utilityFutureStates));
                                
                                stateUtility(ww,tsco,cc,cobs)=IEV+FEV;
                                
                            elseif cc>1 && cc<8
                                
                                %6 Cue states
                                %from condition to outcome, 2 possible choices (actions)
                                %this is where the max operator comes in across choices
                                %so the condition state only reflects the BEST option, not both options
                                actionvalue=zeros(1,2);
                                
                                if (ww+2) >13
                                    %happens when tk count is=12, would've had 6 tsco this would be 7 and invalid to look at future states
                                    %skip these states
                                else
                                    
                                    for choice=1:2
                                        %2 possible choices
                                        
                                        IEV=rew(ww,tsco,cc,cobs); %should be 0
                                        
                                        clearvars nfuturestates utilityFutureStates transitPFutureStates
                                        
                                        %Calculate FEV for each action based on outcome (next state)
                                        %this is where 0.75/0.25 comes in (0.75 rew/ 0.25 no rew) and magnitude of tk reward
                                        %back propogates but there's no encoding of 2 vs 1 token rewarded here directly
                                        %now we have 5 possible outcomes: 0, +1, +2, -1, -2 and associated probabilities
                                        %these transition probabilities are now based on monkey's learning (values from RW model)
                                        
                                        if ww==1 || ww==2
                                            %0 tk
                                            %we can't go negative tk, so we have to account for future states differently, but transition p should stay the same
                                            nfuturestates=5; %0/+1/+2/0from-1/0from-2
                                            transitPsFutureStates(1,1:nfuturestates)=transitP(ww,tsco,cc,cobs,choice+1, 2:nPossibleOutcomes);
                                            utilitiesFutureStates(1,1:nfuturestates)=[stateUtility(ww,tsco,8,1), ... %0tk
                                                stateUtility(ww+1,tsco,8,1), ... %+1
                                                stateUtility(ww+2,tsco,8,1),... %+2
                                                stateUtility(1,tsco,8,1),... %-1 ,if we start with 0 or 1 tk, still goes to 0
                                                stateUtility(1,tsco,8,1)]; %-2, if we start with 0 or 1, still goes to 0
                                        else
                                            nfuturestates=5; %0/+1/+2/-1/-2
                                            transitPsFutureStates(1,1:nfuturestates)=transitP(ww,tsco,cc,cobs,choice+1, 2:nPossibleOutcomes);
                                            utilitiesFutureStates(1,1:nfuturestates)=[stateUtility(ww,tsco,8,1), ... %0tk
                                                stateUtility(ww+1,tsco,8,1), ... %+1
                                                stateUtility(ww+2,tsco,8,1),... %+2
                                                stateUtility(ww-1,tsco,8,1),... %-1
                                                stateUtility(ww-2,tsco,8,1)]; %-2
                                        end
                                        
                                        FEV_single_choice= gamma*(dot(transitPsFutureStates,utilitiesFutureStates));
                                        actionvalue(choice)=IEV+FEV_single_choice;
                                        
                                    end
                                    %Update state utility for the cue condition:
                                    
                                    if length(unique(actionvalue))==1
                                        %equal action values, just pick one randomly
                                        stateUtility(ww,tsco,cc,cobs)=actionvalue(randi(2));
                                        
                                        actionTaken=9; %random action
                                    else
                                        stateUtility(ww,tsco,cc,cobs)=max(actionvalue); %state value is only the value of the best option
                                        
                                        actionTaken= find(actionvalue==max(actionvalue));
                                    end
                                    
                                    %%%%%%%%%THIS IS WHERE WE CAN TRACK POLICY
                                    %add in here which was chosen for a given condition/trial/etc and watch this converge
                                    choicepolicy(iter,ww,tsco,cc,cobs)=actionTaken;
                                    
                                end
                                
                            elseif cc==8
                                
                                %Outcome
                                %from outcome to cashout (cc=9) or ITI (cc=10) ... instead of fixation (cc=1)
                                
                                %Future states include: fixation & cashout for each possible outcome
                                %If we just have one outcome state based on tokens and trials to cashout, then the future possible states=?
                                %if all 5 possible increments in tk, then what would the transition probability be? would make weighting strange
                                %so we'll assume this is the number of updated tokens, then the next states have the same number of tokens?
                                
                                futureCashoutStateP(1,1)=transitP(ww,tsco,9,1,1,1);
                                
                                futureITIStateP(1,1)=1-futureCashoutStateP;
                                
                                if tsco==6
                                    %6 trials since cashout, only next possible state is cashout, not ITI
                                    nfuturestates=1;
                                    utilityFutureStates(1,1:nfuturestates)=[stateUtility(ww,tsco,cc+1,cobs)]; %cashout with additional tokens. cobs updated after cashout
                                    transitPFutureStates=futureCashoutStateP;
                                else
                                    
                                    if cobs==18
                                        %reset cobs to 1
                                        nfuturestates=2;
                                        utilityFutureStates(1,1:nfuturestates)=[stateUtility(ww,tsco,cc+1,1),... %cashout
                                            stateUtility(ww,tsco+1,10,1)]; %ITI
                                        transitPFutureStates=[futureCashoutStateP,futureITIStateP];
                                    else
                                        nfuturestates=3;
                                        utilityFutureStates(1,1:nfuturestates)=[stateUtility(ww,tsco,cc+1,cobs),... %cashout
                                            stateUtility(ww,tsco+1,cc+2,cobs+1), ... %next ITI with this number of tokens associated with the outcome+ one additional trial and nobs +1 (p=1/6)
                                            stateUtility(ww,tsco+1,cc+2,cobs)]; %next ITI with this number of tokens associated with the outcome+ one additional trial nobs doesn't change (p=5/6)
                                        transitPFutureStates=[futureCashoutStateP,futureITIStateP*(1/6),futureITIStateP*(5/6)];
                                        
                                    end
                                    
                                end
                                
                                
                                FEV=gamma*(dot(transitPFutureStates,utilityFutureStates));
                                stateUtility(ww,tsco,cc,cobs)=IEV+FEV;
                                
                            elseif cc==9
                                %Cashout
                                %THE ONLY REWARDED STATES
                                %from outcome to cashout states, but not all trials proceed to these
                                IEV=rew(ww,tsco,cc,cobs);
                                
                                %future state from here is always the same state: ITI with 0 tokens and 0 trials since cashout
                                clearvars nfuturestates utilityFutureStates transitPFutureStates
                                
                                if cobs==18
                                    nfuturestates=1;
                                    utilityFutureStates=stateUtility(1,1,cc+1,1); %reset tk, tsco, reset cobs to 1, go to ITI
                                    transitPFutureStates=1.0;
                                else
                                    nfuturestates=2;
                                    utilityFutureStates(1,1:nfuturestates)=[stateUtility(1,1,cc+1,cobs+1), ...
                                        stateUtility(1,1,cc+1,cobs)]; %also note now nobs is incremented here p= 1/6 for incrementing
                                    transitPFutureStates=[1/6, 5/6];
                                end
                                
                                FEV=gamma*(dot(transitPFutureStates,utilityFutureStates));
                                stateUtility(ww,tsco,cc,cobs)=IEV+FEV;
                                
                            elseif cc==10
                                %Intertrial interval
                                %Only future state is fixation with current tk, tsco, cobs already updated before this
                                IEV=rew(ww,tsco,cc,cobs);
                                clearvars nfuturestates utilityFutureStates transitPFutureStates
                                
                                if cobs==18
                                    nfuturestates=1;
                                    utilityFutureStates=stateUtility(ww,tsco,1,1); %reset cobs to 1
                                    transitPFutureStates=1.0;
                                else
                                    %this might need to be 2 future states with 1/6, 5/6 cobs update, unsure
                                    %but cobs ITI should = cobs next Fix so I think not
                                    nfuturestates=1;
                                    utilityFutureStates=stateUtility(ww,tsco,1,cobs);
                                    transitPFutureStates=1.0;
                                end
                                FEV=gamma*(dot(transitPFutureStates,utilityFutureStates));
                                stateUtility(ww,tsco,cc,cobs)=IEV+FEV;
                                
                                
                                
                            end
                            
                        end
                        
                    end
                end
                
            end
        end
        %calculating difference between last iteration of stateUtility and this one
        stateUtility_delta=stateUtility-stateUtility0;
        
        %RMSE for state utility:
        RMSE_stateUtility(iter)=sqrt(sum(stateUtility_delta.^2,'All')/2); %MAYBE WANT TO CHANGE 2 to N elements in stateutility?
        
        %overwriting for next iter:
        stateUtility0=stateUtility;
        
        
        
        
        toc
        
    end
    
    % option to save this state space:
    formatOut = 'mm_dd_yy';
    mdy=datestr(now,formatOut);
    fname=strcat(mdy,'_gamma_',num2str(gamma),'_monkey_',monkey,'_iter_',num2str(iter),'_M',num2str(CHOOSEMODEL),...
        '_stateSpace_TkS','.mat');
    
    save(fname)
    
    
end