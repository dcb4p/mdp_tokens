%MDPversusTkSBehavior_v2Hua.m
%For processing choice data, abort data, reaction time data and relating to MDP values
%last edit: 05.03.23

%Steps (before this):
%(1) TkS_labDataPreProcessingMDP_v.m: use this to get the RW fit and value curves
%(2) flatMDPtokens_paramOptim_v.m: use this to optimize the parameters to get the transition probabilities for the MDP (compares monk choices to MDP CP)
%(3) flatMDPtokens_TkS_v.m: fit the MDP using the optimized parameters to get the corrected values for the state space


%RTs= Bo + B1*Vt + B2 * (Vt+1 - Vt); %linear regression
%p(abort)= 1/ exp^ -1*(Bo + B1*Vt + B2 * (Vt+1 - Vt)); %logistic regression

%(1)RT to acquire fixation (includes aborts)
%(2)RT to choice (does not include aborts)
%(3)p(abort) 


%NOTE::: in non-recording data, monkey holds fixation for 500ms. In recording data, monkey holds for variable fixation 
%(SEE APPROX LINE 122) where RT to acquire fixation are determined. This needs adjustment if fixation hold time is variable

%updated to calculate error for each session and get distributions of
%errors


%% ~~~~~~~~~~~~~~~~~~Load in raw data and MDP~~~~~~~~~~~~~~~~~~~~:
close all

clear

suppressPlotFlag=1;

%gammaset=[0.8,0.85,0.9,0.925, 0.95, 0.99, 0.999];
gammaset=0.999;

monkey='Uno'; %all betas p<0.01  %%%striated choice reaction times
monkey='Boom'; %all betas p<0.01 %%%striated choice reaction times
monkey='Prima'; %all betas p<0.05, 1.5% overly fast RTs
monkey='Sparkles'; %beta fix: p<0.01, betach1: 0.11, betach2: p<0.01, beta_abort1: p=0.07, beta abort 2: p= 0.26. 20% of correct trials too fast Rts
monkey='AJacks';%beta fix: p<0.01, betach1: p<0.01, betach2: p<0.01, beta_abort1: p<0.01, beta abort 2: p= 0.06

%aborts weird for U/P/S

%%

% monkey='CardiB';
% monkey='Blis';

%*********** choice RTs< 100 ms are removed in choice RT block for Sparkles


for g=1:length(gammaset)
    clearvars -except suppressPlotFlag g gammaset monkey allPValues allErrorMetrics allErrorMetrics_bySession allErrorMetrics_bySession_stderr
   
    gamma_test= gammaset(g);

if strcmp(monkey,'Uno')
    load('UnoMatrix_v3_withAborts.mat'); %monkey behavioral data
    
    %MDP for given gamma:
    %fnameMDP = strcat('05_05_23_gamma_',num2str(gamma_test),'_monkey_Uno_iter_100_M1_stateSpace_TkS.mat');
    fnameMDP = strcat('08_21_23_gamma_',num2str(gamma_test),'_monkey_Uno_iter_100_M1_stateSpace_TkS.mat');
    load(fnameMDP,'stateUtility')
    
    %Params for given gamma:
    fnameParams =strcat('MDP_params_fitDate_05_05_23_monkey_Uno_gamma_',num2str(gamma_test),'.mat');
    load(fnameParams,'pcorr_allFiles','bestparams','fixedparams','modelMeanCueValues_allFiles')

    %RW chosen values for all trials of completed blocks:
    load('Uno_chosenValueData.mat')

    
elseif strcmp(monkey,'Boom')
    load('BoomDatamat.mat')
    %MDP for given gamma:
    %fnameMDP = strcat('05_08_23_gamma_',num2str(gamma_test),'_monkey_Boom_iter_100_M1_stateSpace_TkS.mat');
    %fnameMDP = strcat('06_12_23_gamma_',num2str(gamma_test),'_monkey_Boom_iter_100_M1_stateSpace_TkS.mat');
    fnameMDP = strcat('08_21_23_gamma_',num2str(gamma_test),'_monkey_Boom_iter_100_M1_stateSpace_TkS.mat');
    load(fnameMDP,'stateUtility')
    
    %Params for given gamma:
    %fnameParams =strcat('MDP_params_fitDate_05_08_23_monkey_Boom_gamma_',num2str(gamma_test),'.mat');
    fnameParams =strcat('MDP_params_fitDate_06_12_23_monkey_Boom_gamma_',num2str(gamma_test),'.mat');
    load(fnameParams,'pcorr_allFiles','bestparams','fixedparams','modelMeanCueValues_allFiles')

     %RW chosen values for all trials of completed blocks:
    load('Boom_chosenValueData.mat')
    
elseif strcmp(monkey,'Prima')
    load('PrimaDatamat.mat')
    %MDP for given gamma:
    %fnameMDP = strcat('05_08_23_gamma_',num2str(gamma_test),'_monkey_Prima_iter_100_M1_stateSpace_TkS.mat');
    fnameMDP = strcat('08_21_23_gamma_',num2str(gamma_test),'_monkey_Prima_iter_100_M1_stateSpace_TkS.mat');
    load(fnameMDP,'stateUtility')
    
    %Params for given gamma:
    fnameParams =strcat('MDP_params_fitDate_05_05_23_monkey_Prima_gamma_',num2str(gamma_test),'.mat');
    load(fnameParams,'pcorr_allFiles','bestparams','fixedparams','modelMeanCueValues_allFiles')

     %RW chosen values for all trials of completed blocks:
    load('Prima_chosenValueData.mat')


elseif strcmp(monkey,'Sparkles')
    load('SparklesDatamat.mat')
    %MDP for given gamma:
    %fnameMDP = strcat('05_08_23_gamma_',num2str(gamma_test),'_monkey_Sparkles_iter_100_M1_stateSpace_TkS.mat');
    fnameMDP = strcat('08_21_23_gamma_',num2str(gamma_test),'_monkey_Sparkles_iter_100_M1_stateSpace_TkS.mat');
    load(fnameMDP,'stateUtility')
    
    %Params for given gamma:
    fnameParams =strcat('MDP_params_fitDate_05_05_23_monkey_Sparkles_gamma_',num2str(gamma_test),'.mat');
    load(fnameParams,'pcorr_allFiles','bestparams','fixedparams','modelMeanCueValues_allFiles')

     %RW chosen values for all trials of completed blocks:
    load('Sparkles_chosenValueData.mat')


elseif strcmp(monkey,'AJacks')
    load('AppleJacks_version2.mat')
    %MDP for given gamma:
    %fnameMDP = strcat('05_08_23_gamma_',num2str(gamma_test),'_monkey_AJacks_iter_100_M1_stateSpace_TkS.mat');
    fnameMDP = strcat('08_21_23_gamma_',num2str(gamma_test),'_monkey_AJacks_iter_100_M1_stateSpace_TkS.mat');
    load(fnameMDP,'stateUtility')
    
    %Params for given gamma:
    fnameParams =strcat('MDP_params_fitDate_05_05_23_monkey_AJacks_gamma_',num2str(gamma_test),'.mat');
    load(fnameParams,'pcorr_allFiles','bestparams','fixedparams','modelMeanCueValues_allFiles')

    %RW chosen values for all trials of completed blocks:
    load('AJacks_chosenValueData.mat')


elseif strcmp(monkey,'CardiB')
    load('CardiB.mat')    
elseif strcmp(monkey,'Blis')
    load('Blis.mat')
end



%%

monkeydata=data;

%Specific to this file: remove familiar blocks first:
monkeydataNovelOnly= monkeydata(find(monkeydata(:,2)< 10),:);
monkeydata=monkeydataNovelOnly; clearvars monkeydataNovelOnly data

%Remove 3 weird trials that are mislabeled aborts from AppleJacks' data:
if strcmp(monkey,'AJacks')
    monkeydata(11258:11260,:)=[];
end

%Check/Remove incomplete blocks:
completedtrials=double(monkeydata(:,3)==0);
sessionAndBlkID=monkeydata(:,2).* (monkeydata(:,14)+99591); %unique ID for block & session
uniqueBlkSessions=unique(sessionAndBlkID);

for i=1:length(uniqueBlkSessions)
    blockcount(i)=sum(completedtrials(find(uniqueBlkSessions(i)==sessionAndBlkID)));
end
uniqueblockct=unique(blockcount)

%if there are incomplete blocks then add code to remove them, otherwise:
blocknum=monkeydata(:,2);


% C1 = Session trl number
% C2= Block number
% C3= Trial error: (0=good tr, 4=no fix, 3= broke fix, 5= did not select cue, 6= did not hold selected cue)
% C4 = Condition (including side) – 700
% 1 & 2 = 2 v 1
% 3 & 4 = 1 v -1
% 5 & 6 = 2 v -1
% 7 & 8 = 1 v -2
% 9 & 10 = 2 v -2
% 11 & 12 = -1 v -2
% C5 = Not important for this
% C6 = Cue selected (including side) – 500
% 	14 & 15 = +1 cue
% 	16 & 17 = +2 cue
% 	18 & 19 = -1 cue
% 	20 & 21 = -2 cue
% C7:C8 = not important for this
% C9 = trl since cashout – 33
% C10 = tokens on before choice – 800
% C11 = tokens on after choice – 900
% C12 = Cue selected (no side)
% 	1 = +1 cue
% 	2 = +2 cue
% 	3 = -1 cue
% 	4 = -2 cue
% C13 = Change in tokens after choice
% C14 = Session
% C15 = Condition (no side)
% 1= 2 v 1
% 2 = 1 v -1
% 3 = 2 v -1
% 4 = 1 v -2
% 5 = 2 v -2
% 6 = -1 v -2
% C18 = n/a
% C20 = time of event code 20 (fixation on)
% C22 = time of event code 21 (fixation off)
% C24 = time of event code 40 (cue on) (identical to fixation off)
% C26 = time of event code 41 (choice)

%all sessions, all data (including aborts and familiar blocks):
sessions=monkeydata(:,14);
nsessions=length(unique(sessions));
%reactiontimes=monkeydata(:,18);

%getting reaction times for acquiring fixation and choice:
RT_acquirefix= monkeydata(:,22)-monkeydata(:,20)- 500; %currently includes hold time, whatever that is, this won't work if that time is variable on every trial
reactiontimes=monkeydata(:,26)-monkeydata(:,24); %currently includes hold time, whatever that is
RT_choice=reactiontimes;

trialError=monkeydata(:,3);

%RECODE NaN values to be tsco for that trial:
tsco=monkeydata(:,9)-33+ 1; %1->6 and NaNs for aborts
for i=1:length(tsco)
    if isnan(tsco(i))
        x=1;
        %find next non NaN value in tsco
        while isnan(tsco(i+x))
            %keep going
            x=x+1;
        end
        next_tsco_val=tsco(i+x);
        tsco(i)=next_tsco_val;
    else
    end
end
monkeydata(:,9)=tsco;

%RECODE NaN values to be tk before choice:
currTkBeforeChoice=monkeydata(:,10)-800;
for i=1:length(currTkBeforeChoice)
    if isnan(currTkBeforeChoice(i))
        x=1;
        %find next non NaN value in tsco
        while isnan(currTkBeforeChoice(i+x))
            %keep going
            x=x+1;
        end
        next_currtk_val=currTkBeforeChoice(i+x);
        currTkBeforeChoice(i)=next_currtk_val;
    else
    end
end
monkeydata(:,10)=currTkBeforeChoice;

%NOTE: Change in Tk after choice left as NaN for abort trials since there was no choice
outcomes=monkeydata(:,13);
tkChangeAfterChoice=monkeydata(:,13); %-2,-1,0,1,2
totalTkAfterTrial=currTkBeforeChoice+tkChangeAfterChoice; %BEFORE CASHOUTS (So on cashout trials, this value will be n tokens received)

condition=monkeydata(:,15);
% 1= 2 v 1
% 2 = 1 v -1
% 3 = 2 v -1
% 4 = 1 v -2
% 5 = 2 v -2
% 6 = -1 v -2
choice=monkeydata(:,12); %1= +1 cue, 2= +2 cue, 3= -1 cue, 4= -2 cue




%% ~~~~~~~~~~~~~~~~~~Gathering predictor data needed to do regressions~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`


aborts=1-completedtrials;

%Structure of state space:: stateUtility((1)nCurrTokens, (2)trialsSinceCashout, (3)trial epoch , (4)nobs);
%note that nobs is 1->18 per block for a condition, will have to get this out of the data  

%(1) currTkBeforeChoice

%tsco %(2)

%(3)Trial epoch 
%includes condition and fixation, so for regressions for acquire fixation will have all 1s, others will be 2->7 so condition + 1
trialEpoch_fix=ones(size(monkeydata,1),1);

trialEpoch_cond=condition+1;

%(4) Get nobs from data using session num, block num, condition, completedTrials:
sessionIDs=unique(sessions);

nobs=zeros(size(monkeydata,1),1); %initialize

for ss=1:nsessions
    singlesession=sessionIDs(ss);

    trs=sessions==singlesession;
   
    temp_blockdata=blocknum(trs);
    temp_conditdata=condition(trs);
    temp_completeddata=completedtrials(trs);

    tmpblks=unique(temp_blockdata);
    temp_nobs=zeros(length(temp_completeddata),1);

    for b=1:length(tmpblks)
        singleblock=tmpblks(b);

        tmptmp_conditdata=temp_conditdata(temp_blockdata==singleblock);
        tmptmp_completeddata=temp_completeddata(temp_blockdata==singleblock);

        %create counters for each condition, nobs stays the same across aborts.
        conditcounters=ones(1,6); %first obs=1, initialize counters
        tmptmp_nobs=zeros(length(tmptmp_conditdata),1); %initialize nobs at this level: single block

        for t=1:length(tmptmp_conditdata)
                %for each trial:
                trialcondition=tmptmp_conditdata(t);

                tmptmp_nobs(t)= conditcounters(trialcondition);

                if tmptmp_completeddata(t)==1 
                    conditcounters(trialcondition)=conditcounters(trialcondition)+1;
                else
                    %trial was an abort, do not increment counter
                end

        end

        %back out and put these nobs codes up a level from block to session:
        temp_nobs(temp_blockdata==singleblock)=tmptmp_nobs;

    end

    %back out one more level to put nobs codes in for entire session:
    nobs(trs)=temp_nobs;

end



datasubset_fix=[currTkBeforeChoice+1,tsco,trialEpoch_fix,nobs]; %add 1 for state coding for curr tk (0tk =idx 1)

datasubset_choice=[currTkBeforeChoice+1,tsco,trialEpoch_cond,nobs];
all_nobs=nobs;

%% ~~~~~~~~~~~~~(1) RT to acquire fixation (with aborts) Regression using fixation state value only (Vfix)

%RTs= Bo + B1*Vt (fix); %linear regression on state values

%this currently uses the mean of all the values for the cue conditions for the difference in state value for t and t+1

        % if B1= positive, when value goes up from avg of cue possibilities, RT will go up (slower)

%datasubset_fix=[currTkBeforeChoice+1,tsco,trialEpoch_fix,nobs];

%option to remove outliers:
removeOutliers=1;


for tr=1:size(datasubset_fix,1)

    %get values and value differences trial by trial:

    v_fix(tr)=stateUtility(datasubset_fix(tr,1),datasubset_fix(tr,2),datasubset_fix(tr,3),datasubset_fix(tr,4));


end

clearvars x y betas_RTacqfix
for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions==singlesession);

    %x= [v_fix(trs)', dv_fix(trs)'];
    x= [v_fix(trs)'];


    % Option to remove outliers: 5.21.23:
    %Tukey's method identifies RTs as outlier, which are larger than the third quartile plus
    %1.5 times the IQR (> q0.75 + 1.5×IQR)
    %or smaller than the first quartile minus 1.5 times the IQR (< q0.25−1.5×IQR).

    %Remove outliers before taking the log:

    if removeOutliers==1
        y_temp= RT_acquirefix(trs);
        iqr_acqFix= iqr(y_temp);
        q1= quantile(y_temp,0.25);
        q3=quantile(y_temp,0.75);
        lowOutliers= find(y_temp < (q1-iqr_acqFix*1.5));
        highOutliers= find(y_temp > (q3+iqr_acqFix*1.5));
        to_remove=[lowOutliers;highOutliers];
        y_temp(to_remove)=[];
        x(to_remove)=[];
        y=log(y_temp); %log rts
        
    else

        %Option 1: raw rts
        %y=RT_acquirefix(trs);


        %Option 2: log rts
        y=log(RT_acquirefix(trs));
    end


    % remove NaNs!!!
    tmp_toremove=isnan(y);
    y(tmp_toremove)=[];
    x(tmp_toremove)=[];

    betas_RTacqfix(ss,:)=glmfit(x,y,'normal');

end


meanBetas_RTacqfix=mean(betas_RTacqfix);
stderrBetas_RTacqfix=stderr(betas_RTacqfix);

if suppressPlotFlag==0
    
    figure();set(gcf,'Color',[1 1 1])
    bar(meanBetas_RTacqfix(2:end)); hold on
    errorbar(1:size(x,2), meanBetas_RTacqfix(2:end), stderrBetas_RTacqfix(2:end),'k','LineStyle','none')
    xticklabels({'β_V_{fix}'})
    ylabel('Mean beta for RT acquire fix, linear reg (s.e.m. across sessions)')
    set(gca,'FontSize',14)
    title('RT acquirefix with aborts, linear regression on V_{fix}')
end

%t-test for significance from zero
[hB_acqfix,pB_acqfix]=ttest(betas_RTacqfix(:,2));

totalerr_acqFixRT=[];




%~~~~~~~~~~~~~~Calculate error in actual v. predicted reaction times:
y_actual_allSS=[];
x_allSS=[];


for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions==singlesession);

    x= [v_fix(trs)'];

    if removeOutliers==1
        y_temp= RT_acquirefix(trs);
        iqr_acqFix= iqr(y_temp);
        q1= quantile(y_temp,0.25);
        q3=quantile(y_temp,0.75);
        lowOutliers= find(y_temp < (q1-iqr_acqFix*1.5));
        highOutliers= find(y_temp > (q3+iqr_acqFix*1.5));
        to_remove=[lowOutliers;highOutliers];
        y_temp(to_remove)=[];
        x(to_remove)=[];
        y_actual=log(y_temp); %log rts

    else
        y_actual=log(RT_acquirefix(trs));
    end

    % remove NaNs!!!
    tmp_toremove=isnan(y_actual);
    y_actual(tmp_toremove)=[];
    x(tmp_toremove)=[];

    y_pred= betas_RTacqfix(ss,1) + x.*betas_RTacqfix(ss,2);

    err_acqFixRT = y_actual-y_pred;


    meanRMSE_acqFixRT(ss)=  sqrt(mean(err_acqFixRT.^2)); %session by session error

    %saving mean *actual* (not log) reaction times across sessions:
    %meanRT_pred(ss)=mean(exp(y_pred));
    %meanRT_actual(ss)=mean(exp(y_actual));

  meanRT_pred(ss)=mean(y_pred);
  meanRT_actual(ss)=mean(y_actual);
%     
    %(1) Plot single session, values v. reaction times
    if ss==10 
        smallestVal=min(x);
        largestVal=max(x);

        RT1=betas_RTacqfix(ss,1) + largestVal.*betas_RTacqfix(ss,2);
        RT2=betas_RTacqfix(ss,1) + smallestVal.*betas_RTacqfix(ss,2);

        RT1=exp(RT1);
        RT2=exp(RT2);

        figure(ss)
        set(gcf,'Color',[1 1 1])
        scatter(x,exp(y_actual),'ko','MarkerFaceColor','c'); hold on; plot([smallestVal largestVal],[RT2 RT1],'k-','LineWidth',2)
        xlabel('V_{fix}'); ylabel('acquire Fix RT ')
        set(gca,'FontSize',14)
    end




    %(2) for each session, bin Vfix and get mean RTs for this bin
%     max_x=ceil(max(x));
%     min_x=floor(min(x));
    max_x=24;
    min_x=10;
    acqfix_bins=min_x:max_x;
    nbins=max_x-min_x;% 1 unit bins
    %nbins=(max_x-min_x)/2; %2unit  bins
    for nb=1:nbins
        binnedtrials=find(x > (min_x + (nb-1)) & x < min_x + nb); %1 unit bins

        %binnedtrials=find(x >= (min_x + 2*(nb-1)) & x < min_x + 2*nb); %2 unit bins

        binnedtrials_acqrt=exp(y_actual(binnedtrials));
        meanbinnedtrs_acqrt(ss,nb)=mean(binnedtrials_acqrt);
        
    end


    %Save ALL trials of RTs and values in one vector for kernel smoothing for each animal:
    y_actual_allSS=[y_actual_allSS;y_actual];
    x_allSS=[x_allSS;x];

end

%MSE_acqFixRT=mean(totalerr_acqFixRT); %error averaged across sessions

overallAvg_RMSE_acqFixRT=mean(meanRMSE_acqFixRT);
stderr_RMSE_acqFixRT=stderr(meanRMSE_acqFixRT);


%~~~~~~~~~~~colors for monkeys:
if strcmp(monkey,'Uno')
    mnkc=[255 102 102]/255;
    cc='ro-';
elseif strcmp(monkey,'Boom')
    mnkc=[255 178 102]/255;
    cc='mo-'; %should be orange but this isn't a basic matlab color
elseif strcmp(monkey,'Prima')
    mnkc=[255 255 102]/255;
    cc='yo-';
elseif strcmp(monkey,'Sparkles')
    mnkc=[102 255 102]/255;
    cc='go-';
elseif strcmp(monkey,'AJacks')
    mnkc=[102 178 255]/255;
    cc='bo-';
end


%~~~~~~Plot binned Vs and mean RTs for these bins:
mean_binnedtrs_acqrt=mean(meanbinnedtrs_acqrt);
stderr_binnedtrs_acqrt=std(meanbinnedtrs_acqrt);

figure(777)
set(gcf,'Color',[1 1 1])
%shadedErrorBar((1:nbins) + min_x-1,mean_binnedtrs_acqrt,stderr_binnedtrs_acqrt,{char(cc),'markerfacecolor',mnkc},1); hold on
shadedErrorBar((1:length(mean_binnedtrs_acqrt))+(min_x-1),mean_binnedtrs_acqrt,stderr_binnedtrs_acqrt,{char(cc),'markerfacecolor',mnkc},1); hold on
xlabel('Binned V_{fix}')
ylabel('MeanRT')



%(3)~~~~~~Kernel smoothing instead of binning
%[yp, xvi] = smooth1d(y, x, sigma, varargin)
sigma=0.5;
[yp, xvi] = smooth1d(y_actual_allSS, x_allSS, sigma);
% figure(999);
% set(gcf,'Color',[1 1 1])
% plot(xvi,exp(yp),cc); hold on
% scatter(x_allSS,exp(y_actual_allSS))
% set(gca,'FontSize',14)
% xlabel('Vx'); ylabel('RT')

%(4)~~~~~~Find 95% of the data from mean Vfix value and just use this data with kernel smoothing:
mu_x = mean(x_allSS);                   
STDdat = std(x_allSS);
lowlim= mu_x - 2*STDdat;
highlim=mu_x + 2*STDdat;

trunc_y_actual_allSS=y_actual_allSS(find(x_allSS<highlim & x_allSS> lowlim));
trunc_x_allSS=x_allSS(find(x_allSS<highlim & x_allSS> lowlim));

sigma=1;
[yp, xvi] = smooth1d(trunc_y_actual_allSS, trunc_x_allSS, sigma);
figure(875);
set(gcf,'Color',[1 1 1])
plot(xvi,exp(yp),'Color',mnkc); hold on
%scatter(trunc_x_allSS,exp(trunc_y_actual_allSS))
set(gca,'FontSize',14)
xlabel('V_{fix}'); ylabel('acquireFix RT'); title('95% CI data')

%name these values for saving later:
xAcqFix_smoothed=xvi;
yAcqFixRT_smoothed=exp(yp);

%bootstrap to get error bars:
%acqFixRT_stdev_smoothed


if 0
    %scatter plot of RTs predicted vs actual:
    figure(12389)
    set(gcf,'Color',[1 1 1])
    scatter(meanRT_actual,meanRT_pred,75,'k','MarkerFaceColor',mnkc); hold on
    %pltmax=(round(max([meanRT_actual,meanRT_pred]))+50);
    %pltmin=(round(min([meanRT_actual,meanRT_pred]))-50);
    pltmax=6; pltmin=3;
    plot([pltmin pltmax],[pltmin,pltmax],'k')
    xlabel('Mean ln(RT) (actual))'); ylabel('Mean ln(RT) (predicted)-acqFix'); legend(strcat('n=',num2str(ss),'sessions'))
    set(gca,'FontSize',14)

end

%% new%% ~~~~~~~~~~~~~~~~(1b) RT to acquire fixation, multivariate regression on the features themselves (datasubset_fix), with abort trials:


%datasubset_fix=[currTkBeforeChoice+1,tsco,trialEpoch_fix,nobs]; %1 was added to tk to get state value, need to subtract one off again and don't need trial epoch

datasubset_fix_4Lreg= [currTkBeforeChoice, tsco, nobs];

clearvars betas_RTacqfix_multivariateReg betas

for ss=1:nsessions

    clearvars x y 

    singlesession=sessionIDs(ss);
    trs=find(sessions==singlesession);

    x=datasubset_fix_4Lreg(trs,:);

    % Option to remove outliers: 5.21.23:
    %Tukey's method identifies RTs as outlier, which are larger than the third quartile plus
    %1.5 times the IQR (> q0.75 + 1.5×IQR)
    %or smaller than the first quartile minus 1.5 times the IQR (< q0.25−1.5×IQR).

    %Remove outliers before taking the log:

    if removeOutliers==1
        y_temp= RT_acquirefix(trs);
        iqr_acqFix= iqr(y_temp);
        q1= quantile(y_temp,0.25);
        q3=quantile(y_temp,0.75);
        lowOutliers= find(y_temp < (q1-iqr_acqFix*1.5));
        highOutliers= find(y_temp > (q3+iqr_acqFix*1.5));
        to_remove=[lowOutliers;highOutliers];
        
        y_temp(to_remove)=[];
        y=log(y_temp); %log rts

        x(to_remove,:)=[];        
    else

        %Option 1: raw rts
        %y=RT_acquirefix(trs);

        %Option 2: log rts
        y=log(RT_acquirefix(trs));
    end


    % remove NaNs!!!
    tmp_toremove=isnan(y);
    y(tmp_toremove)=[];
    x(tmp_toremove,:)=[];


    %[betas,sigma]=mvregress(x,y);
    %the model is y= XiB + e, where X = predictor variables, B= regression
    %coefficients, e are the error terms each with multivariate normal distribution 
    %won't change the way I'm doing regression

    tmp_betas=glmfit(x,y,'normal');


    betas_RTacqfix_multivariateReg(ss,:)=tmp_betas;

end


meanBetas_RTacqfix_multivariateReg=mean(betas_RTacqfix_multivariateReg);
stderrBetas_RTacqfix_multivariateReg=stderr(betas_RTacqfix_multivariateReg);

if suppressPlotFlag==0
    figure(1234)
    set(gcf,'Color',[1 1 1])
    bar(meanBetas_RTacqfix_multivariateReg); hold on
    errorbar(1:3,meanBetas_RTacqfix_multivariateReg,stderrBetas_RTacqfix_multivariateReg,'k','LineWidth',2,'LineStyle','none')
    xticklabels({'NTk','TSCO','NObs'})
    set(gca,'FontSize',14)
end



%% ~~~~~~~~~~~~~(2) RT to choice (does not include aborts) Regression using cue state values and state value differences (Vcue, Vcue-Vfix):
%RTs= Bo + B1*Vt + B2 * (Vt+1 - Vt); %linear regression on state values

        % if B1= negative, when value goes up, RT will go down (faster)
        % if B2= positive, when state value for cue drops, this will be a small positive number (eg loss loss condit), RTs will go up (slower)

%datasubset_choice=[currTkBeforeChoice,tsco,trialEpoch_cond,nobs];

%dv: change to fix not outcome

%option to remove outliers using Tukey method:
removeOutliers=1;

clearvars v dv
%remove aborts:

datasubset_choice_ct=datasubset_choice(find(completedtrials==1),:);

datasubset_fix_ct=datasubset_fix(find(completedtrials==1),:);

for tr=1:size(datasubset_choice_ct,1)

    %get state values and value differences trial by trial:
    

    %original: v is for cue state:
    v_cue_ct(tr)=stateUtility(datasubset_choice_ct(tr,1),datasubset_choice_ct(tr,2),datasubset_choice_ct(tr,3),datasubset_choice_ct(tr,4));

    %dv: Vcue- Vfix
    dv_ct(tr)= v_cue_ct(tr)-stateUtility(datasubset_choice_ct(tr,1),datasubset_choice_ct(tr,2),1,datasubset_choice_ct(tr,4)); %vcue-vfix

    %dv_ct(tr)=stateUtility(datasubset_choice_ct(tr,1),datasubset_choice_ct(tr,2),1,datasubset_choice_ct(tr,4)); %fix only

    trialinfotmp(tr,1:4)=datasubset_choice_ct(tr,:);
    trialinfotmp(tr,5)=v_cue_ct(tr);
    trialinfotmp(tr,6)=dv_ct(tr);
end

% figure(1239); [counts,centers] = hist(trialinfotmp(:,1),max(unique(trialinfotmp(:,1))))
% bar(centers,counts,'b'); hold on; xlabel('ntokens');ylabel('hist'); 


%~~~~~~~~~~~~~~(1) Regression on choice RTs for each session:

sessions_ct= sessions(find(completedtrials==1));
reactiontimes_ct=reactiontimes(find(completedtrials==1));

%~~~~~Option to remove too fast RTs for Sparkles:
if strcmp(monkey,'Sparkles')
    tooFastRTs=find(reactiontimes_ct<100);
    v_cue_ct(tooFastRTs)=[];
    dv_ct(tooFastRTs)=[];
    sessions_ct(tooFastRTs)=[];
    reactiontimes_ct(tooFastRTs)=[];
end


clearvars x y betas_RTchoice
y_actual_allSS=[];
x1_allSS=[];
x2_allSS=[];

for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions_ct==singlesession);

    x= [v_cue_ct(trs)', dv_ct(trs)']; %original v and dv
    %x= [v_ct(trs)'];

    % Option to remove outliers: 5.21.23:
    %Tukey's method identifies RTs as outlier, which are larger than the third quartile plus
    %1.5 times the IQR (> q0.75 + 1.5×IQR)
    %or smaller than the first quartile minus 1.5 times the IQR (< q0.25−1.5×IQR).

    %Remove outliers before taking the log:

    if removeOutliers==1
        y_temp= reactiontimes_ct(trs);
        iqr_acqFix= iqr(y_temp);
        q1= quantile(y_temp,0.25);
        q3=quantile(y_temp,0.75);
        lowOutliers= find(y_temp < (q1-iqr_acqFix*1.5));
        highOutliers= find(y_temp > (q3+iqr_acqFix*1.5));
        to_remove=[lowOutliers;highOutliers];
        y_temp(to_remove)=[];
        x(to_remove,:)=[];
        y_actual=log(y_temp); %log rts

    else

        %y=reactiontimes_ct(trs);
        y_actual=log(reactiontimes_ct(trs));
    end

    % remove NaNs!!!
    tmp_toremove=isnan(y_actual);
    y_actual(tmp_toremove)=[];
    x(tmp_toremove,:)=[];


    betas_RTchoice(ss,:)=glmfit(x,y_actual,'normal');

    %Save ALL trials of RTs and values in one vector for kernel smoothing for each animal:
    y_actual_allSS=[y_actual_allSS;y_actual];
    x1_allSS=[x1_allSS;x(:,1)];
    x2_allSS=[x2_allSS;x(:,2)];


    %(2) Plot single session, values v. reaction times
    if ss==15
        smallestVal=min(x(:,1));
        largestVal=max(x(:,1));

        smallestDVal=min(x(:,2));
        largestDVal=max(x(:,2));

        %V and dV = 1, V = 2, dV = 3:

        xaxisVar=2

        if xaxisVar==1

            %(1)using Both V and dV:
            RT1=betas_RTchoice(ss,1) + largestVal.*betas_RTchoice(ss,2)+ largestDVal.*betas_RTchoice(ss,3);
            RT2=betas_RTchoice(ss,1) + smallestVal.*betas_RTchoice(ss,2)+ smallestDVal.*betas_RTchoice(ss,3);

        elseif xaxisVar==2
            %(2)using V only:
            RT1=betas_RTchoice(ss,1) + largestVal.*betas_RTchoice(ss,2);
            RT2=betas_RTchoice(ss,1) + smallestVal.*betas_RTchoice(ss,2);

        elseif xaxisVar==3

            %(3)using dV only:
            RT1=betas_RTchoice(ss,1) + largestDVal.*betas_RTchoice(ss,3);
            RT2=betas_RTchoice(ss,1) + smallestDVal.*betas_RTchoice(ss,3);
        end

        RT1=exp(RT1);
        RT2=exp(RT2);

        if suppressPlotFlag==0

            if xaxisVar==2
                %(1)using V:

                figure(ss+100)
                scatter(x(:,1),exp(y_actual),'ko','MarkerFaceColor','c'); hold on;
                plot([smallestVal largestVal],[RT2 RT1],'k-','LineWidth',2); xlabel('V_{cue}');

            elseif xaxisVar==3
                %(2)using dV:

                figure(ss+110)
                scatter(x(:,2),exp(y_actual),'ko','MarkerFaceColor','c'); hold on;
                plot([smallestDVal largestDVal],[RT2 RT1],'k-','LineWidth',2); xlabel('V_{cue}- V_{fix}');

            end
                set(gcf,'Color',[1 1 1])
            ylabel(' RT choice')
            set(gca,'FontSize',14)
        end
    end

end


meanBetas_RTchoice=mean(betas_RTchoice);
stderrBetas_RTchoice=stderr(betas_RTchoice);

if suppressPlotFlag==0
    figure();set(gcf,'Color',[1 1 1])
    bar(meanBetas_RTchoice(2:end)); hold on
    errorbar(1:size(x,2), meanBetas_RTchoice(2:end), stderrBetas_RTchoice(2:end),'k','LineStyle','none')
    if size(x,2)==2
        xticklabels({'β_V_{cue}','β_{ (V_{cue}-V_{fix})}'})
        
    elseif size(x,2)==1
        xticklabels({'β_V'})
    end
    %
    
    ylabel('Mean beta for RT choice, linear reg (s.e.m. across sessions)')
    set(gca,'FontSize',14)
    title('RTchoice, linear regression on V_{cue} and dV=(V_{cue}-V_{fix})')
    
end

%t-test for significance from zero
[hB1,pB1]=ttest(betas_RTchoice(:,2));
[hB2,pB2]=ttest(betas_RTchoice(:,3));

%test if betas are significantly different from each other
%[ht_rtchoice,pval_rtchoice]=ttest2(betas_RTchoice(:,2),betas_RTchoice(:,3))

clearvars x
meanRMSE_choiceRT=[];

%~~~~~~~~~~~~~~(2) Calculate error in actual v. predicted reaction times:
for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions_ct==singlesession);

    x= [v_cue_ct(trs)', dv_ct(trs)']; %original v and dv


    if removeOutliers==1
        y_temp= reactiontimes_ct(trs);
        iqr_acqFix= iqr(y_temp);
        q1= quantile(y_temp,0.25);
        q3=quantile(y_temp,0.75);
        lowOutliers= find(y_temp < (q1-iqr_acqFix*1.5));
        highOutliers= find(y_temp > (q3+iqr_acqFix*1.5));
        to_remove=[lowOutliers;highOutliers];
        y_temp(to_remove)=[];
        x(to_remove,:)=[];
        
        y_actual=log(y_temp); %log rts

    else
        y_actual=log(reactiontimes_ct(trs));
    end

    y_pred= betas_RTchoice(ss,1) + betas_RTchoice(ss,2).*x(:,1) + betas_RTchoice(ss,3).*x(:,2);


    meanchoiceRT_pred(ss)=mean(y_pred);
    meanchoiceRT_actual(ss)=mean(y_actual);

    err_choiceRT = y_actual-y_pred;

    %totalerr_choiceRT = [totalerr_choiceRT; err_choiceRT.^2]; %squared%error old way

     meanRMSE_choiceRT(ss)=  sqrt(mean(err_choiceRT.^2)); %session by session error
end

%MSE_choiceRT=mean(totalerr_choiceRT);


    overallAvg_RMSE_choiceRT=mean(meanRMSE_choiceRT);
    stderr_RMSE_choiceRT=stderr(meanRMSE_choiceRT);


%Scatter plot of RTs predicted vs actual:
    %colors for monkeys:
    if strcmp(monkey,'Uno')
        mnkc=[255 102 102]/255;
    elseif strcmp(monkey,'Boom')
        mnkc=[255 178 102]/255;
    elseif strcmp(monkey,'Prima')
        mnkc=[255 255 102]/255;
    elseif strcmp(monkey,'Sparkles')
        mnkc=[102 255 102]/255;
    elseif strcmp(monkey,'AJacks')
        mnkc=[102 178 255]/255;
    end

if 0

    figure(10001)
    set(gcf,'Color',[1 1 1])
    scatter(meanchoiceRT_actual,meanchoiceRT_pred,75,'k','MarkerFaceColor',mnkc); hold on
    pltmax=5.65; pltmin=5.2;
    plot([pltmin pltmax],[pltmin,pltmax],'k')
    xlabel('Mean ln(RT) (actual)-choice)'); ylabel('Mean ln(RT) (predicted)-choice'); legend(strcat('n=',num2str(ss),'sessions'))
    set(gca,'FontSize',14)
    xlim([pltmin pltmax])
    ylim([pltmin pltmax])
end

%for sparkles, ss=1,4,5,17 have super fast average RTs down to 115ms
    propChoiceRTslessThan100ms=length(find(reactiontimes_ct<100))/length(reactiontimes_ct);


%(3)~~~~~~Kernel smoothing instead of binning
%[yp, xvi] = smooth1d(y, x, sigma, varargin)
sigma=1;
[yp1, xvi1] = smooth1d(y_actual_allSS, x1_allSS, sigma);

[yp2, xvi2] = smooth1d(y_actual_allSS, x2_allSS, sigma);

if 0
    figure(991);
    set(gcf,'Color',[1 1 1])
    plot(xvi1,exp(yp1),'Color',mnkc,'LineWidth',1.5); hold on
    set(gca,'FontSize',14)
    xlabel('V_{cue}'); ylabel('choice RT'); title('All data Vcue')

    figure(992);
    set(gcf,'Color',[1 1 1])
    plot(xvi2,exp(yp2),'Color',mnkc,'LineWidth',1.5); hold on
    set(gca,'FontSize',14)
    xlabel('V_{cue}-V_{fix}'); ylabel('choice RT'); title('All data Vcue-Vfix')
    %scatter(x2_allSS,exp(y_actual_allSS))
end


%(4)~~~~~~Find 95% of the data from mean Vfix value and just use this data with kernel smoothing:
%~~~Vcue:
mu_x = mean(x1_allSS);                   
STDdat = std(x1_allSS);
lowlim= mu_x - 2*STDdat;
highlim=mu_x + 2*STDdat;

trunc_y_actual_allSS=y_actual_allSS(find(x1_allSS<highlim & x1_allSS> lowlim));
trunc_x_allSS=x1_allSS(find(x1_allSS<highlim & x1_allSS> lowlim));

sigma=1;

[yp3, xvi] = smooth1d(trunc_y_actual_allSS, trunc_x_allSS, sigma);
if 0
    figure(222);
    set(gcf,'Color',[1 1 1])
    plot(xvi,exp(yp3),'Color',mnkc,'LineWidth',1.5); hold on
    set(gca,'FontSize',14)
    xlabel('V_{cue}'); ylabel('choice RT'); title('95% CI data')
end

%~~~Vcue-Vfix
mu_x = mean(x2_allSS);                   
STDdat = std(x2_allSS);
%lowlim= mu_x - 2*STDdat;
%highlim=mu_x + 2*STDdat;

%trunc_y_actual_allSS2=y_actual_allSS(find(x2_allSS<highlim & x2_allSS> lowlim));
%trunc_x_allSS2=x2_allSS(find(x2_allSS<highlim & x2_allSS> lowlim)); %remove "outliers" but in this case only 1/5 of trials are <0 so this is removing these trials

%don't truncate in X:
trunc_y_actual_allSS2=y_actual_allSS;
trunc_x_allSS2=x2_allSS;

sigma=1;
[yp4, xvi2] = smooth1d(trunc_y_actual_allSS2, trunc_x_allSS2, sigma);

if 0
    figure(333);
    set(gcf,'Color',[1 1 1])
    plot(xvi2,exp(yp4),'Color',mnkc,'LineWidth',1.5); hold on
    set(gca,'FontSize',14)
    xlabel('V_{cue}-V_{fix}'); ylabel('choice RT'); title('95% CI data')
end

%save these for saving across animals:
xRTchoice_Vcue_smoothed=xvi;
xRTchoice_dV_smoothed=xvi2;

yRTchoice_Vcue_smoothed=exp(yp3);
yRTchoice_dV_smoothed=exp(yp4);


%% new%% ~~~~~~~~~~~~~~~~(2b) RT to choice, regression with chosen value from RW:

%regress using chosenVals_allFilesConcat instead of datasubset_choice_ct

%calculate error in predicted and actual RTs and compare to error using state value and change in state value ??

%RTs= Bo + B1*RW_chovt ; %linear regression on RW chosen value
    % if B1= negative, when value goes up, RT will go down (faster)

%option to remove outliers using Tukey method (removed above in 2 block)
removeOutliers=1;

%reactiontimes_ct

clearvars x y betas_RTchoiceRW
y_actual_allSS=[];
x1_allSS=[];
x2_allSS=[];

for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions_ct==singlesession);

    %x= [v_cue_ct(trs)', dv_ct(trs)']; %what we originally regressed on

    x=[chosenVals_allFilesConcat(trs)];

    % Option to remove outliers: 5.21.23:
    %Tukey's method identifies RTs as outlier, which are larger than the third quartile plus
    %1.5 times the IQR (> q0.75 + 1.5×IQR)
    %or smaller than the first quartile minus 1.5 times the IQR (< q0.25−1.5×IQR).

    %Remove outliers before taking the log:

    if removeOutliers==1
        y_temp= reactiontimes_ct(trs);
        iqr_acqFix= iqr(y_temp);
        q1= quantile(y_temp,0.25);
        q3=quantile(y_temp,0.75);
        lowOutliers= find(y_temp < (q1-iqr_acqFix*1.5));
        highOutliers= find(y_temp > (q3+iqr_acqFix*1.5));
        to_remove=[lowOutliers;highOutliers];
        y_temp(to_remove)=[];
        x(to_remove,:)=[];
        y_actual=log(y_temp); %log rts

    else

        %y=reactiontimes_ct(trs);
        y_actual=log(reactiontimes_ct(trs));
    end

    % remove NaNs!!!
    tmp_toremove=isnan(y_actual);
    y_actual(tmp_toremove)=[];
    x(tmp_toremove,:)=[];


    betas_RTchoiceRW(ss,:)=glmfit(x,y_actual,'normal');

    %Save ALL trials of RTs and values in one vector for kernel smoothing for each animal:
    y_actual_allSS=[y_actual_allSS;y_actual];
    x1_allSS=[x1_allSS;x(:,1)];

end

if strcmp(monkey,'Prima')
    %remove file outliers
    idxToRemove=find(abs(betas_RTchoiceRW(:,2))>10);
    betas_RTchoiceRW(idxToRemove,:)=[];

end


meanBetas_RTchoiceRW=mean(betas_RTchoiceRW);
stderrBetas_RTchoiceRW=stderr(betas_RTchoiceRW);

if suppressPlotFlag==0
    figure();set(gcf,'Color',[1 1 1])
    bar(meanBetas_RTchoiceRW(2:end)); hold on
    errorbar(1:size(x,2), meanBetas_RTchoiceRW(2:end), stderrBetas_RTchoiceRW(2:end),'k','LineStyle','none')
    if size(x,2)==1
        xticklabels({'β_{RW}_{chosenvalue}'})
 
    end
    %
    
    ylabel('Mean beta for RT choice, linear reg (s.e.m. across sessions)')
    set(gca,'FontSize',14)
    title('RTchoice, linear regression on RW_{chosenvalue}')
    
end

%t-test for significance from zero
[hB1,pB1]=ttest(betas_RTchoiceRW(:,2));


%% new%% ~~~~~~~~~~~~~~~~(2c) RT to choice, multivariate regression: NTk, TSCO, TE(condition),NObs
%datasubset_choice_ct :: currTkBeforeChoice+1,tsco,trialEpoch_cond,nobs
%for completed trials only, selected earlier. subtract 1 from first column


%option to remove outliers using Tukey method (removed above in 2 block)
removeOutliers=1;

%reactiontimes_ct

clearvars x y betas_RTchoice_multivarReg conditionCategTE
y_actual_allSS=[];
x1_allSS=[];
x2_allSS=[];

% conditionCategTE={};
% conditionCategTE{1}='c1';conditionCategTE{2}='c2';conditionCategTE{3}='c3';
% conditionCategTE{4}='c4';conditionCategTE{5}='c5';conditionCategTE{6}='c6';
% 
% categoricalCondition= cell(length(datasubset_choice_ct(:,3),1));
% for c=1:length(unique(datasubset_choice_ct(:,3)))
%     tmpTrialList=zeros(length(datasubset_choice_ct(:,3),1));
%     tmpTrialList(find(datasubset_choice_ct(:,3)==c+1))=1;
%     tmpTrialList=logical(tmpTrialList);
%     categoricalCondition(tmpTrialList)=cconditionCategTE(c);
% end

for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions_ct==singlesession);

    %x= [v_cue_ct(trs)', dv_ct(trs)']; %what we originally regressed on

    x=[ datasubset_choice_ct(trs,1)-1, datasubset_choice_ct(trs,2), datasubset_choice_ct(trs,3), datasubset_choice_ct(trs,4)];

    if removeOutliers==1
        y_temp= reactiontimes_ct(trs);
        iqr_acqFix= iqr(y_temp);
        q1= quantile(y_temp,0.25);
        q3=quantile(y_temp,0.75);
        lowOutliers= find(y_temp < (q1-iqr_acqFix*1.5));
        highOutliers= find(y_temp > (q3+iqr_acqFix*1.5));
        to_remove=[lowOutliers;highOutliers];
        y_temp(to_remove)=[];
        x(to_remove,:)=[];
        y_actual=log(y_temp); %log rts

    else

        %y=reactiontimes_ct(trs);
        y_actual=log(reactiontimes_ct(trs));
    end

    % remove NaNs!!!
    tmp_toremove=isnan(y_actual);
    y_actual(tmp_toremove)=[];
    x(tmp_toremove,:)=[];

    %currTkBeforeChoice+1,tsco,trialEpoch_cond,nobs
    %*******************again we have to pick a reference variable for cue
    %condition, could be +2 v +1 or -2 v -1 ? 
    %******************should we report all the regressors?
    mdl=fitlm(x,y_actual,'CategoricalVars',3);

    
    RTchoiceCoeffsAllDat=mdl.Coefficients;
    RTchoiceCoeffs=RTchoiceCoeffsAllDat{:,1};
    RTchoiceCoeffs=RTchoiceCoeffs(2:end);

    betas_RTchoice_multivarReg(ss,:)=RTchoiceCoeffs';
end





%% ~~~~~~~~~~~~~(3) p(abort) (logistic regression: Vcue, Vcue-Vfix)
% log(p_abort/1-p_abort) = Bo + B1*Vcue + B2 * (Vcue - Vfix) ; %logistic regression on state values and diffs
%
%use both:
%datasubset_fix=[currTkBeforeChoice+1,tsco,trialEpoch_fix,nobs]; %add 1 for state coding for curr tk (0tk =idx 1)
%datasubset_choice=[currTkBeforeChoice+1,tsco,trialEpoch_cond,nobs];

%When early aborts happen, the condition isn't shown

%we have these from the previous block (2) for all trials including aborts:
%v_fix(tr)

clearvars v_cue dv
for tr=1:size(datasubset_fix,1)

    %get values and value differences trial by trial:
    v_cue(tr)=stateUtility(datasubset_choice(tr,1),datasubset_choice(tr,2),datasubset_choice(tr,3),datasubset_choice(tr,4));

    dv(tr)= v_cue(tr)-v_fix(tr);

end


clearvars x y betas_abort

predAbortAllTrials=[];
meanPredAbortAll=[];
totalerr_pAbort=[];
x_Vcue_predAbort_allSS=[];

for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions==singlesession);

    x=[v_cue(trs)', dv(trs)'];

    y=aborts(trs);

    betas_abort(ss,:) = glmfit(x,y,'binomial','link','logit');

    %predicted abort probability by trial:
    pred_abort= 1./ (1 + exp(-1*(betas_abort(ss,1)+ v_cue(trs)'.*betas_abort(ss,2) + dv(trs)'.*betas_abort(ss,3))) );
    predAbortAllTrials= [predAbortAllTrials; pred_abort];

    %get loglikelihood:
    %if abort: log(p)
    %if not abort: log(1-p)

    all_ps=y.*pred_abort  + (1-y).*(1-pred_abort);
    ll= log(all_ps);


    pAbort_ll(ss)= sum(ll);

    %investigate weirdness of aborts in Boom:
%     if strcmp(monkey,'Boom') && ss==10
%         clearvars fabort_binned
% 
%         binsize=25; %trials to bin
%         nbins=round(length(y)/binsize);
%         for b=1:nbins
%             if b==nbins
%                 trb= 1+(b-1)*binsize : length(y);
%                 fabort_binned(b)=sum(y(trb))/length(trb);
%             else
%                fabort_binned(b)=sum(y(1+(b-1)*binsize : binsize +(b-1)*binsize ))/binsize;
%             end
% 
%         end
%         figure(1234)
%         plot(1:nbins, fabort_binned,'o-'); hold on
%         ylabel('proportion of trials in 25 sequential trials, that were aborts'); xlabel('25 trial bin')
%     end


    %Save ALL trials of pAborts and values in one vector for kernel smoothing for each animal:
    y_predAbort_allSS=predAbortAllTrials;
    x_Vcue_predAbort_allSS=[x_Vcue_predAbort_allSS;x(:,1)];


end

%total_pAbort_negll= -1*sum(pAbort_ll); %negative log likelihood (to minimize) original way sum over all sessions

overallAvg_negLL_pAbort= -1*mean(pAbort_ll);
stderr_negLL_pAbort=stderr(pAbort_ll);


meanBetas_aborts=mean(betas_abort);
stderrBetas_aborts=stderr(betas_abort);


if suppressPlotFlag==0
    figure();set(gcf,'Color',[1 1 1])
    bar(meanBetas_aborts(2:end)); hold on
    errorbar(1:size(x,2), meanBetas_aborts(2:end), stderrBetas_aborts(2:end),'k','LineStyle','none')
    xticks([1 2])
    xlim([0 3])
    %ylim([-0.26 0])
    xticklabels({'β_V_{cue}','β_{ (V_{cue}-V_{fix})}'})
    ylabel('Mean beta for p(abort), logistic reg (s.e.m. across sessions)')
    set(gca,'FontSize',14)
    
    title('p(abort), logistic regression on V_{cue} and dV (V_{cue}-V_{fix})')
    
end

%t-test for significance from zero
[hB1_pabort,pB1_pabort]=ttest(betas_abort(:,2));
[hB2_pabort,pB2_pabort]=ttest(betas_abort(:,3));

%test if betas are significantly different from each other
[ht_abort,pval_abort]=ttest2(betas_abort(:,2),betas_abort(:,3));


%(3)~~~~~~Kernel smoothing instead of binning
%[yp, xvi] = smooth1d(y, x, sigma, varargin)
sigma=0.5;
[yp_abort, xvi_abort] = smooth1d(y_predAbort_allSS, x_Vcue_predAbort_allSS, sigma);

% figure(123);
% set(gcf,'Color',[1 1 1])
% plot(xvi_abort,yp_abort,cc); hold on
% set(gca,'FontSize',14)
% xlabel('V_{cue}'); ylabel('p(abort)')

%(4)~~~~~~Find 95% of the data from mean Vcue value and just use this data with kernel smoothing:
mu_x = mean(x_Vcue_predAbort_allSS);                   
STDdat = std(x_Vcue_predAbort_allSS);
lowlim= mu_x - 2*STDdat;
highlim=mu_x + 2*STDdat;

trunc_y_actual_allSS=y_predAbort_allSS(find(x_Vcue_predAbort_allSS<highlim & x_Vcue_predAbort_allSS> lowlim));
trunc_x_allSS=x_Vcue_predAbort_allSS(find(x_Vcue_predAbort_allSS<highlim & x_Vcue_predAbort_allSS> lowlim));


sigma=0.5;
[yp_abort_trunc, xvi_abort_trunc] = smooth1d(trunc_y_actual_allSS, trunc_x_allSS, sigma);
figure(124);
set(gcf,'Color',[1 1 1])
plot(xvi_abort_trunc,yp_abort_trunc,'Color',mnkc,'LineWidth',1.5); hold on
set(gca,'FontSize',14)
xlabel('V_{cue}'); ylabel('p(abort)'); title('95% CI data')

%Plotting p(abort) versus Vcue
x_Vcue=lowlim:0.01:highlim;
y_pAbort_Vcue = 1./ (1 + exp(-1*(meanBetas_aborts(1)+ x_Vcue'.*meanBetas_aborts(2)) ));

figure(444); set (gcf,'Color',[1 1 1])
plot(x_Vcue,y_pAbort_Vcue,'Color',mnkc);hold on
set(gca,'FontSize',14)
xlabel('V_{cue}'); ylabel('p(Abort)'); title('p(abort)')
legend('p(abort)=B_o+ B_1*V_{cue}')


%save for avg across monkeys:

xpAbort_Vcue_smoothed=xvi_abort_trunc;
ypAbort_Vcue_smoothed=yp_abort_trunc;



%% ~~~~~~~~~~~~~~~~(3b) Testing p(abort) model -- session by session

%use betas_abort vs fabort for each session
ntok=4; 
trialssinceco=2;
nobs=18;

clearvars fabort_SS yfit_SS
for ss=1:nsessions
    singlesession=sessionIDs(ss);

    for c=1:6
        totaltrials=length(find(datasubset_choice(:,3)==c+1 & sessions==singlesession)); %coding is 2-7 for condition in mdp
        aborttrials=length(find(datasubset_choice(:,3)==c+1 & aborts==1 & sessions==singlesession)); %all aborts

        fabort_SS(ss,c)=aborttrials/totaltrials;
    end

    %Original: get tmpV and tmpdV trial by trial? might need to change this, rough approx using fixed # of tok, tsco, nobs:

    tmpV(:,:)=stateUtility(ntok,trialssinceco,2:7,nobs);
    tmpdV(:,:)=tmpV-stateUtility(ntok,trialssinceco,1,nobs); %used to be fix - cue

    %New way, average across all tk, tsco, nobs for each condition
    clearvars tmpV_mean_condit tmpdV_mean_condit
    for condc=2:7
        tmp1(:,:,:)=stateUtility(:,:,condc,:);
        tmpV_mean_condit(condc-1)=mean(mean(mean(tmp1(tmp1~=0))));

        tmp2(:,:,:)=stateUtility(:,:,1,:);
        tmpdV_mean_condit(condc-1)= mean(mean(mean(tmp1(tmp1~=0))))- mean(mean(mean(tmp2(tmp2~=0))));
    end
    tmpV=tmpV_mean_condit';
    tmpdV=tmpdV_mean_condit';


    xtest= [tmpV,tmpdV];
    n= 1000000*ones(6,1);
    b_ss=betas_abort(ss,:)';
    yfit_SS(ss,:) = glmval(b_ss,xtest,'logit','Size',n);
end

ypred_SS=yfit_SS./n(1);

%mean fabort across sessions:
meanfabort_SS=nanmean(fabort_SS);

%colors for monkeys:
if strcmp(monkey,'Uno')
    mnkc=[255 102 102]/255;
elseif strcmp(monkey,'Boom')
    mnkc=[255 178 102]/255;
elseif strcmp(monkey,'Prima')
    mnkc=[255 255 102]/255;
elseif strcmp(monkey,'Sparkles')
    mnkc=[102 255 102]/255;
elseif strcmp(monkey,'AJacks')
    mnkc=[102 178 255]/255;
end



if suppressPlotFlag==0
    condit6={'2v1','1v -1','2 v -1','1 v -2','2 v -2','-1 v -2'};
    for c=1:6
        figure(1108);set(gcf,'Color',[1 1 1])
        subplot(2,3,c)
        scatter(fabort_SS(:,c), ypred_SS(:,c),[],mnkc,"filled"); hold on
        scatter(fabort_SS(:,c), ypred_SS(:,c),[],'k')
        plot(0:0.1:1.0,0:0.1:1.0,'k-')
        xlabel('fabort')
        ylabel('pred abort mdp and logreg')
        title(condit6(c))
        ylim([0,1])
        xlim([0,1])
        
    end
    
end

%% ~~~~~~~~~~~~~~~~(3c) p(abort) (logistic regression: Vcue only, simpler)
% log(p_abort/1-p_abort) = Bo + B1*Vcue ; %logistic regression on state values and diffs
%
%use both:
%datasubset_fix=[currTkBeforeChoice+1,tsco,trialEpoch_fix,nobs]; %add 1 for state coding for curr tk (0tk =idx 1)
%datasubset_choice=[currTkBeforeChoice+1,tsco,trialEpoch_cond,nobs];

%When early aborts happen, the condition isn't shown

%we have these from the previous block (2) for all trials including aborts:
%v_fix(tr)

clearvars v_cue dv
for tr=1:size(datasubset_fix,1)

    %get values and value differences trial by trial:
    v_cue(tr)=stateUtility(datasubset_choice(tr,1),datasubset_choice(tr,2),datasubset_choice(tr,3),datasubset_choice(tr,4));

    dv(tr)= v_cue(tr)-v_fix(tr);

end


clearvars x y 

predAbortAllTrials=[];
meanPredAbortAll=[];
totalerr_pAbort=[];
for ss=1:nsessions
    singlesession=sessionIDs(ss);
    trs=find(sessions==singlesession);

    x=[v_cue(trs)'];

    y=aborts(trs);

    betas_abort_v2(ss,:) = glmfit(x,y,'binomial','link','logit');

    %predicted abort probability by trial:
    pred_abort= 1./ (1 + exp(-1*(betas_abort_v2(ss,1)+ v_cue(trs)'.*betas_abort_v2(ss,2))) );
    predAbortAllTrials= [predAbortAllTrials; pred_abort];

    %get loglikelihood:
    %if abort: log(p)
    %if not abort: log(1-p)

    all_ps=y.*pred_abort  + (1-y).*(1-pred_abort);
    ll= log(all_ps);


    pAbort_ll(ss)= sum(ll);

end

%total_pAbort_negll= -1*sum(pAbort_ll); %negative log likelihood (to minimize) original way sum over all sessions

overallAvg_negLL_pAbort= -1*mean(pAbort_ll);
stderr_negLL_pAbort=stderr(pAbort_ll);


meanBetas_aborts_v2=mean(betas_abort_v2);
stderrBetas_aborts_v2=stderr(betas_abort_v2);


if suppressPlotFlag==0
    figure();set(gcf,'Color',[1 1 1])
    bar(meanBetas_aborts_v2(2)); hold on
    errorbar(1, meanBetas_aborts_v2(2), stderrBetas_aborts_v2(2),'k','LineStyle','none')
    xlim([0 2])

    xticklabels({'β_V_{cue}'})
    ylabel('Mean beta for p(abort), logistic reg (s.e.m. across sessions)')
    set(gca,'FontSize',14)
    
    title('p(abort), logistic regression on V_{cue} only')
    
end

%t-test for significance from zero
[hB1_pabort,pB1v2_pabort]=ttest(betas_abort_v2(:,2));

%% new%% ~~~~~~~~~~~~~~~~(3c) Multivariate logistical regression on MDP features not values (NTk, TSCO, TE (condition, including fixation), NObs)

%we will need to be a bit fancier here with TE, fixation and condition being a categorical variable and all others being continuous
%use both:
%datasubset_fix=[currTkBeforeChoice+1,tsco,trialEpoch_fix,nobs]; %add 1 for state coding for curr tk (0tk =idx 1)
%datasubset_choice=[currTkBeforeChoice+1,tsco,trialEpoch_cond,nobs];

%go trial by trial and figure out when abort happened--- if no fix, broke fix, no choice, no choice hold
codedAborts=monkeydata(:,3);
typesOfTrials=unique(codedAborts); %0= completed, 3,4 fixation abort... 5,6 choice abort
typesOfTrialsCateg={};
typesOfTrialsCateg{1}='completed';typesOfTrialsCateg{2}='abortFix';typesOfTrialsCateg{3}='abortFix';
typesOfTrialsCateg{4}='abortChoice';typesOfTrialsCateg{5}='abortChoice';

categoricalTrialType= cell(length(monkeydata),1);

for type=1:length(typesOfTrials)
    tmpTrialList=zeros(length(monkeydata),1);
    tmpTrialList(find(monkeydata(:,3)==typesOfTrials(type)))=1;
    tmpTrialList=logical(tmpTrialList);
    categoricalTrialType(tmpTrialList)=typesOfTrialsCateg(type);
end

%Now use this to pick the correct task epoch, fixation or choice and turn
%the categorical variable into {fix, cond1 -> cond 6}

%Each completed trial would be double counted? 
%Sort of incorporates state into the regression.. this is complicated. 
%we could treat fixation aborts as choice aborts and just look at cue
%condition as a categorical variable that way :

%%%%%%% this is another thing to mention in the reply why this is all very silly ! 

%%%%%%%%%%%%%%%%%Option 1: Conditions= Cue Cond 1-6, treat aborts that
%%%%%%%%%%%%%%%%%happened during fixation by their cue condition
conditionNumbers=unique(trialEpoch_cond); %2-7 = c1 -> c6
conditionCateg={};
conditionCateg{1}='c1';
conditionCateg{2}='c2';
conditionCateg{3}='c3';
conditionCateg{4}='c4';
conditionCateg{5}='c5';
conditionCateg{6}='c6';

categoricalCondition= cell(length(trialEpoch_cond),1);

for cond=1:length(conditionNumbers)

    tmpTrialList=zeros(length(trialEpoch_cond),1);
    tmpTrialList(find(trialEpoch_cond==conditionNumbers(cond)))=1;
    tmpTrialList=logical(tmpTrialList);

    categoricalCondition(tmpTrialList)=conditionCateg(cond);
end

%%%%%%%%%%%%%%%%%Option 2: Conditions= Fix, Cue Cond 1-6
%We can create a "c0" to indicate abort happened during fixation before cues came on:
%caveat to this is all 'fix' conditions will be aborts this way:

abortCondit={};
abortCondit{1}='fix';
for abortType=3:4
    %for fixation aborts:

    tmpTrialList=zeros(length(monkeydata),1);

    tmpTrialList(find(monkeydata(:,3)==abortType))=1;
    tmpTrialList=logical(tmpTrialList);

    categoricalCondition(tmpTrialList)=abortCondit;
end


%%%%Option3: Regress on fix aborts and choice aborts separately

for abortType=1:2

    %abortType 1 = fixation aborts, no condition variable in fitglm
    %abortType 2 = choice aborts, use condition in fitglm

    for ss=1:nsessions

        clearvars x y

        singlesession=sessionIDs(ss);

        if abortType==1
            %fixation aborts and completed trials (0/3/4), remove choice abort trials

            trs=find(sessions==singlesession & codedAborts <5);
           
        elseif abortType==2
            %choice aborts 0/5/6, remove fixation abort trials
            recodedchoiceaborttrs=zeros(length(codedAborts),1);
            recodedchoiceaborttrs(find(codedAborts>4))=1;
            recodedchoiceaborttrs(find(codedAborts==0))=1;
            trs=find(sessions==singlesession & recodedchoiceaborttrs==1 );
        end


        categoricalCondition_trs=categoricalCondition(trs);
        currTkBeforeChoice_trs=currTkBeforeChoice(trs);
        tsco_trs=tsco(trs);
        all_nobs_trs=all_nobs(trs);
        aborts_trs=aborts(trs);

 

        %%%Perform Logistic Regression:

        % Create a GeneralizedLinearModel object by using fitglm or stepwiseglm.
        % fitglm fits a generalized linear regression model to data using a fixed model specification. Use addTerms, removeTerms,
        % or step to add or remove terms from the model. Alternatively, use stepwiseglm to fit a model using stepwise generalized linear regression.



        if abortType==1

            abortTbl=table(currTkBeforeChoice_trs,tsco_trs,all_nobs_trs, aborts_trs);
            mdl=fitglm(abortTbl,'Distribution','binomial');

            abortCoeffsAllDat=mdl.Coefficients;
            abortCoeffs=abortCoeffsAllDat{:,1};
            abortCoeffsOrdered_fixAborts=abortCoeffs(2:4); %Ntk, tsco, nobs

            abortCoeffs_fixAborts(ss,:)=abortCoeffsOrdered_fixAborts;

        elseif abortType==2

            %choiceAborts

            %Input table:
            %datasubset_choice=[currTkBeforeChoice+1,tsco,trialEpoch_cond,nobs]; with
            %our new categorical variable "categoricalCondition" instead of "trialEpoch_cond"
            %A reference variable needed for categorical variables...

            %Response variable is "aborts" which is the last variable in the response table tbl
            %logit(aborts) ~ 1 + currTkBeforeChoice + tsco + nobs + categoricalCondition

            %We can choose the reference variable by moving a that trial trial to the top, don't alter original vectors :
            %making fix the reference doesn't actually make sense bc all of those are aborts

            idxFixAborts= double(strcmp(categoricalCondition_trs,'c1')).* [1:length(categoricalCondition_trs)]';
            idxFirstAbort=find(idxFixAborts>0,1);

            all_currTkBeforeChoice_trs=[currTkBeforeChoice_trs(idxFirstAbort);currTkBeforeChoice_trs]; %put this trial first
            all_currTkBeforeChoice_trs(idxFirstAbort+1)=[]; %remove duplicate

            all_tsco_trs = [tsco_trs(idxFirstAbort); tsco_trs];
            all_tsco_trs(idxFirstAbort+1)=[];

            all_nobs2_trs = [all_nobs_trs(idxFirstAbort); all_nobs_trs];
            all_nobs2_trs(idxFirstAbort+1)=[];

            all_categoricalCondition_trs = [categoricalCondition_trs(idxFirstAbort); categoricalCondition_trs];
            all_categoricalCondition_trs(idxFirstAbort+1)=[];

            all_aborts_trs = [aborts_trs(idxFirstAbort); aborts_trs];
            all_aborts_trs(idxFirstAbort+1)=[];

            abortTbl=table(all_currTkBeforeChoice_trs,all_tsco_trs,all_nobs2_trs,all_categoricalCondition_trs, all_aborts_trs);

             mdl=fitglm(abortTbl,'Distribution','binomial','CategoricalVars',4);

            clearvars abortCoeffsOrdered
    
            abortCoeffsAllDat=mdl.Coefficients;
            abortCoeffs=abortCoeffsAllDat{:,1};
            abortCoeffsOrdered(1,:)=abortCoeffs(2:4); %currTk, tsco, nobs
    
            %rearrange coefficients for condition to be 2,3,4,5,6 since this seems randomly chosen by fitglm:
            %5-9
            clearvars tmpc coeforder
            for coef=5:9
                tmpc=abortCoeffsAllDat.Row{coef};
                newstrs=split(tmpc,'_c');
                coeforder(coef)= str2double(newstrs(3));
            end
    
            %get remaining 5 coefficients for cue condition in order 2,3,4,5,6
            for coef=1:5
                coefidx=find(coeforder==coef+1);
    
                abortCoeffsOrdered=[abortCoeffsOrdered,abortCoeffs(coefidx)];  %abortCoeffsOrdered is: currTk, TSCO, NObs, Cond 2-6
            end
            abortCoeffsOrdered_choiceAborts=abortCoeffsOrdered;

            abortCoeffs_choiceAborts(ss,:)=abortCoeffsOrdered_choiceAborts;
        end




    end

end




%% ~~~~~~~~~~~~~(4) Pupil diameter / Linear regression

% 


MSE_pupil=NaN;

%% print pvals
pB_acqfix, pB1, pB2, pB1_pabort, pB2_pabort , pB1v2_pabort

%% ~~~~~~~~~~~~~(5) MDP_CP vs. Behavior

%recompute dt for given gamma: 
    [rmse, dt_gamma] = fitMDPmodelParams_M1(bestparams, fixedparams, modelMeanCueValues_allFiles, stateUtility, pcorr_allFiles, gamma_test);

totalerr_CP=[];

for c=1:6

    mdp_cp=dt_gamma(c,:);
    

    pcorrSingleCondition(:,:)=pcorr_allFiles(:,c,:);
    pcorr_mean=nanmean(pcorrSingleCondition);
    pcorr_mean(isnan(pcorr_mean))=[];

    err_cp= pcorr_mean-mdp_cp; %difference between mdp cp and mean behavior
    err_cp=err_cp';
    totalerr_CP = [totalerr_CP; err_cp.^2]; %squared error
    
    % Option to plot MDP_CP versus behavior across gammas:
    if 1
        colrs={'r-';'y-';'g-';'b-';'c-';'m-';'r--'};
        condit6={'2v1','1v -1','2 v -1','1 v -2','2 v -2','-1 v -2'};
        figure(111)
        set(gcf,'Color',[1 1 1])
        subplot(2,3,c)
        if g==1
            %plot(1:18,pcorr_mean,'k','LineWidth',1.5); hold on
            plot(1:18,pcorr_mean,'ko-','LineWidth',1.5); hold on
        end
        plot(1:18,mdp_cp,'m-','LineWidth',1.5); hold on
        %plot(1:18,mdp_cp,char(colrs(g,:)),'LineWidth',1.5); hold on
        xlabel('trial')
        title(condit6(c))
        ylim([0.4 1.01])
        xticks([1,9,18])
        xlim([0,20])
    end

end

RMSE_CP=sqrt(mean(totalerr_CP));





%% Pvalues

allPValues(g,:)= [gamma_test, pB_acqfix,pB1 ,pB2, pB1_pabort,pB2_pabort];



%% Errors

% allErrorMetrics(g,:)=[gamma_test, MSE_acqFixRT, MSE_choiceRT, total_pAbort_negll,  MSE_CP, MSE_pupil];
% 
% gamma_used= gamma_test;
% acqFixRT_err=  MSE_acqFixRT;
% choiceRT_err=  MSE_choiceRT;
% pAbort_negLL= total_pAbort_negll;
% pupil_err= NaN;
% cp_err = MSE_CP;
% 
% T=table(gamma_used, acqFixRT_err, choiceRT_err, pAbort_negLL, cp_err, pupil_err)

allErrorMetrics_bySession(g,:)= [gamma_test, ...
    overallAvg_RMSE_acqFixRT,  ...
    overallAvg_RMSE_choiceRT,  ...
    overallAvg_negLL_pAbort, ...
    RMSE_CP];
allErrorMetrics_bySession_stderr(g,:)= [gamma_test, stderr_RMSE_acqFixRT, stderr_RMSE_choiceRT,stderr_negLL_pAbort];




end

%% Plot errors for each behavioral metric by gamma values (original, all sessions summed)
% allErrorMetrics_names= {'gamma_test', 'MSE_{acqFixRT}', 'MSE_{choiceRT}',...
%     'NegLL_{pAbort}',  'MSE_{CP}', 'MSE_pupil'};
% x=allErrorMetrics(:,1);
% 
% for i=2:5
%     figure(9876)
%     set(gcf,'Color',[1 1 1])
%     subplot(1,4,i-1)
%     plot(x,allErrorMetrics(:,i),'bo-'); hold on
%     xticks(gammaset)
%     xlim([0.79 1.0])
%     title(char(allErrorMetrics_names{i}))
%     xlabel('Gamma')
% end

%% Plot distributions of errors (across sessions) by gamma values

if length(gammaset)>1
    allErrorMetrics_names= {'gamma_test', 'RMSE_{acqFixRT}', 'RMSE_{choiceRT}',...
        'NegLL_{pAbort}',  'RMSE_{CP}'};
    x=allErrorMetrics_bySession(:,1);

    for i=2:5
        figure(1234)
        set(gcf,'Color',[1 1 1])
        subplot(1,4,i-1)

        if i==5
            plot(x,allErrorMetrics_bySession(:,i),'bo-');
            ylabel('RMSE (mean behv - mdp cp)')
        else
            shadedErrorBar(x,allErrorMetrics_bySession(:,i),allErrorMetrics_bySession_stderr(:,i),{'b-o','markerfacecolor','k'},1); hold on
            %errorbar(x,allErrorMetrics_bySession(:,i),allErrorMetrics_bySession_stderr(:,i))
            if i==4
                ylabel('Mean negLL (across sessions)')
            else
                ylabel('Mean error (across sessions)')
            end
        end

        xticks(gammaset)
        xlim([0.79 1.0])
        xtickangle(-45)
        title(char(allErrorMetrics_names{i}))
        xlabel('Gamma')


    end




    %% Plot p-values for each metric by gamma values

    allBetaVal_names= {'gamma_test','B1_{acqfix}', 'B1_{rtchoice}', 'B2_{rtchoice}',...
        'B1_{pabort}',  'B2_{pabort}'};
    x=allPValues(:,1);

    for i=2:6
        figure(98)
        set(gcf,'Color',[1 1 1])
        subplot(1,5,i-1)
        plot(x,allPValues(:,i),'mo-'); hold on
        xticks(gammaset)
        xlim([0.79 1.0])
        title(char(allBetaVal_names{i}))
        xlabel('Gamma')
        plot([0.79, 1.0],[0.05 0.05],'k--')
        xtickangle(-45)
    end
end

%% saving regressors for analysis across monkeys:

%saving all betas for each monkey not just averages

if gamma_test==0.999
    formatOut = 'mm_dd_yy';
    mdy=datestr(now,formatOut);

    fname=strcat('MDPregressors_',mdy,'_monkey_',monkey,'_gamma_',num2str(gamma_test),'.mat');
    save(fname,'betas_RTacqfix', 'betas_RTchoice', 'betas_abort', 'betas_abort_v2','mean_binnedtrs_acqrt',...
        'acqfix_bins','meanfabort_SS','xAcqFix_smoothed','yAcqFixRT_smoothed',...
    'xRTchoice_Vcue_smoothed', 'xRTchoice_dV_smoothed','yRTchoice_Vcue_smoothed','yRTchoice_dV_smoothed',...
    'xpAbort_Vcue_smoothed','ypAbort_Vcue_smoothed',...
    'betas_RTacqfix_multivariateReg','betas_RTchoiceRW','betas_RTchoice_multivarReg','abortCoeffs_fixAborts','abortCoeffs_choiceAborts'); %new regressions for replies to reviewers, all sessions for each monkey
end


