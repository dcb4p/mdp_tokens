function [rmse] = fitMDPmodelParams_rmse_M1(params, fixedparams, modelMeanCueValues_allFiles, stateUtility, pcorr_allFiles, gamma)


%this fits Model 1 (M1) parameters for the MDP for the Tokens task (TkS with +1 +2 -1 -2 cues)
%gamma currently taken from base MDP

%%%%%%%%%%%%%% MODIFICATION!!! NOTE THIS COMMENTED OUT NOT TO PIN VALS TO 0 09.12.23
%%%%%%%%%%%%%% MODIFICATION!!! NOTE THIS COMMENTED OUT TO MAKE STD The SAME SINGLE VALUE IN TIME 0 09.21.23

k_compress=params(1);

if ~isempty(fixedparams)
    beta_all=fixedparams;
else
    beta_all=params(2);
end


%% Getting value distributions to get p(tk|vi,ai) and functions

%From RW analysis of TkS data from Uno

%getting distributions of values for the 4 options across trials:

for cue=1:4
    singleCueVals(:,:)=modelMeanCueValues_allFiles(:,cue,:);

    %Decide to use mean or median values (median less subj to outlier sessions). Note that this is the median value curve of mean value curves from each session:
    %mean_singleCueVals(cue,:)=mean(singleCueVals);
    mean_singleCueVals(cue,:)=median(singleCueVals);

    %Feature of this model: Compress all value curves with 1 free parameter:
    mean_singleCueVals(cue,:)=k_compress*mean_singleCueVals(cue,:); 

    %set v(obs1) to 0 at obs 1:
    %mean_singleCueVals(cue,1)=0; %%%%%%%%%%%%%% MODIFICATION!!! NOTE THIS COMMENTED OUT NOT TO PIN VALS TO 0 09.12.23
   
    stdev_singleCueVals(cue,:)=std(singleCueVals);

end

%fix std for all curves to the to mean std changing across time, no scaling parameter:
%meanStdev=mean(stdev_singleCueVals); %%%%%%%%%%%%%% MODIFICATION!!! NOTE THIS COMMENTED OUT TO MAKE STD The SAME SINGLE VALUE IN TIME 0 09.21.23

meanStdev=mean(mean(stdev_singleCueVals));

for cue=1:4
    stdev_singleCueVals(cue,:)=meanStdev;
end




% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Create table of transition probabilities for the possible tabular states~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%(kind of like a transition model T(s,a,s')

%~~~~~~~~~~~~~~State features:
%current tk- 
%trials since cashout
%trial epoch (fix, cue, outcome, cashout)
%condition (set of cues)
%number of times each condition has been seen
%possible outcomes--(0/+1/+2/-1/-2)

transitP=[];

%max values for 

max_nCurrTokens=13; %(0 through 12 max tk )
max_trialsSinceCashout=6; %(1 through 6)
ntrialEpochs=10; % (1)fix, (2-7)condition/choice *6, (8)outcome, (9)cashout (10) intertrial interval
max_nobs_conditions=18; %1 through 18 times a condition can be seen, but we will maybe sample this to reduce dimensionality if needed
nPossibleChoices=3; %no choice yet/choice 1/choice2
nPossibleOutcomes=6; %no outcome yet/0/+1/+2/-1/-2 (5 possible outcomes + none yet)
nconditions=6;

%most of the transitions are 0.0 because you can't get to many states from
%other states... transp=1/6 from fixation to any of the 6 conditions and
%then 0.75 or 0.25 or 0 for choice to outcome for particular choices of
%0,1,or2 tokens, and then growing probability of a cashout trial from 4 to
%7 trials.

%later we can include aborts as actions at different task epoch points:
transitP=zeros(max_nCurrTokens,max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions,nPossibleChoices, nPossibleOutcomes); 


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Construct transition probability matrix~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%note that true transition probability to condition is not 1/6 except on the first trial, because all conditions are presented before repeating.

%6 conditions, not all have the same possible outcomes, this is where we get the p=1/6 for condition and 0.75/0.25 probabilities in there based on choice: 
%6 conditions collapsed by side:
            % 1= 1 v 2   %possible outcomes: 1,0 // 2,0 (best= opt 2 in all other cases)
            % 2 = 1 v -1 %possible outcomes: 1,0 // -1,0 (best= opt 1 in all other cases)
            % 3 = 2 v -1 %possible outcomes: 2,0 // -1,0
            % 4 = 1 v -2 %possible outcomes: 1,0 // -2,0  
            % 5 = 2 v -2 %possible outcomes: 2,0 // -2,0
            % 6 = -1 v -2 %possible outcomes: -1,0 // -2,0

%in simple version w/ one kind of tk, conditions should have slightly different values once learned (based on best outcome):
% Highest
% Med
% Highest
% Med
% Highest
% Lowest


%Trial epochs: (1)Fixation, (2) Condition/choice, (3)Outcome, (4)Cashout time
%condition, choice, outcome don't affect fixation, aren't known yet at that time in the trial
%outcome doesn't affect condition onset in the same way, isn't known yet.

%Set transition probabilities from fixation to condition epoch, no choice or outcome yet:
ptrans=1/6;
transitP(:,:,2:7,:,1,1)=ptrans; %doesn't need to be inside loop, some extra states for choices & outcomes that don't need to be filled

%transitP=zeros(max_nCurrWaterTokens, max_trialsSinceCashout,ntrialEpochs,max_nobs_conditions,nPossibleChoices, nPossibleOutcomes);

for cond=1:nconditions
    % conditions 1-6

    for nobs=1:max_nobs_conditions

        for choice=1:2
            % choice1 or choice2 (index 1 handled below at transitP)

            %we now have probability of choice based on condition and number of times observed too, so that can be pulled from those curves created above to affect choice behavior later on.

            %Here we want to bring in what the 2 options are to use *those* two mean values for calculating posterior probabilities for the 4 possible outcomes in addition to 0 tk

            % 1= 1 v 2   %possible outcomes: 1,0 // 2,0 (best= opt 2 in all other cases)
            % 2 = 1 v -1 %possible outcomes: 1,0 // -1,0 (best= opt 1 in all other cases)
            % 3 = 2 v -1 %possible outcomes: 2,0 // -1,0
            % 4 = 1 v -2 %possible outcomes: 1,0 // -2,0
            % 5 = 2 v -2 %possible outcomes: 2,0 // -2,0
            % 6 = -1 v -2 

                conditionCueInfo= [1,2; ... %<<1 v 2 >>
                    1,3; ... %<<1 v -1>>
                    2,3;...  %<<2 v -1>>
                    1,4;...  %<<1 v -2>>
                    2,4;...  %<<2 v -2>>
                    3,4];    %<<-1 v -2>>

            choiceCue=conditionCueInfo(cond,choice);


            for otc=2:nPossibleOutcomes
                %previously this is where 80/20 probabilities came in for each condition and were coded as a lookup table, independent of trial.

                %Now we have distributions of values and can ask: what is the probability that a state value comes from one of these 4 distributions?
                %order: none, 0, +1, +2, -1, -2
%                 if nobs==1 %%%%%%%%%%%%%% MODIFICATION!!! NOTE THIS COMMENTED OUT NOT TO PIN VALS TO 0 09.12.23
%                     %nobs=1 is 0 obs, so everything is equally likely, but still 25% chance of no reward
%                     if otc==2
%                         ptrans=0.25;
%                     else
%                         ptrans=0.75/4;
%                     end
%                 else
                    if otc==2
                        %We still use 75/25 for 25% chance of no reward:
                        ptrans=0.25;

                    else
                        %otc= 3,4,5,6  // +1, +2, -1, -2

                        %Calculating 4 posterior probabilities for each outcome given mean v associated with choice:
                        %using Bayes rule, where x=1:4 possible outcomes
                        % p(tkx|v) = [p(v|tkx)* p(tkx)] / p(v)
                        %p(tkx)=0.25
                        %p(v)= total probability of observing v (mean v from curves for the chosen option)
                        %p(v)= p(v|tk1)*p(tk1) + p(v|tk2)*p(tk2) + p(v|tk2)*p(tk2) + p(v|tk4)*p(tk4)
                        %p(v|tkx)= p(v|mu,sigma) = normpdf(v,u,sigma) --> trapz

                        %v=mean_singleCueVals(choiceCue-2,nobs); %3456
                        v=mean_singleCueVals(choiceCue,nobs);

                        p_tkx=0.75; %prior is 0.75, assume monkey knows 75/25 rwd sched

                        %p_tkx=0.75/4;

                        cdf_tkx_given_v=[];
                        p_v_given_tkx=[];
                        for cueval=1:4

                            %try different way, just using gaussian function, not integrating:
                            sigma=stdev_singleCueVals(cueval,nobs);
                            mu=mean_singleCueVals(cueval,nobs);
                            x=mean_singleCueVals(choiceCue,nobs);
                            p_v_given_tkx(cueval)= (1/(sigma*sqrt(2*pi)))*exp(-0.5*(((x-mu)/sigma).^2));

                        end

                        pv=sum(p_v_given_tkx);

                        p_tkx_given_v= (p_v_given_tkx(otc-2)*p_tkx)/pv;

                        ptrans=p_tkx_given_v; %transition probability to the four remaining possible outcomes: 2J/1J/2W/1W
                    end
%                 end
                
                transitP(:,:,cond+1,nobs,choice+1,otc)=ptrans; %this is set for each choice and condition info is also brought in above
                %Note that with inspection, it seems 1J is more likely than 1W and 2W (slightly) even at nobs=max. Not sure why, but k=Nstdev being lower decreases it a bit. 


            end
        end
    end

end


% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Test transition probabilities to produce CP:
%Use converged state space to get state values
%compute action values for choices based on the new transition probabilities for gaining tokens
%do this for each condition
%get max(action values) for each condition and trial
%compare this to choice probability
%fit kstdev and kcompress parameters to get these curves to best fit cp of monkey

%use same code as previously used to calculate transition probabilities, only difference is we don't load the transition probabilities
%in that SS file, but the ones produced above this block.

transitPTest=transitP;

ntk=4;
trialsSinceCashout=5;
dt=[];
d=[];

for nobs=1:18
    for condition=1:6

        %compute 2 action values at time of choice
        %pass through logistic func to get choice probability for that trial
        %update num tk based on choice and 80/20 probabilities
        %every 4-7 trials, cashout and reset tk to 0

        %action values at time of choice:

        for choice=1:2
            nfuturestates=5; %0/+1/+2+/-1/-2
            transitPsFutureStates(1,1:nfuturestates)=transitPTest(ntk,trialsSinceCashout,condition+1,nobs,choice+1, 2:nPossibleOutcomes);
            utilitiesFutureStates(1,1:nfuturestates)=[stateUtility(ntk,trialsSinceCashout,8,1), ... %0tk
                stateUtility(ntk+1,trialsSinceCashout,8,1), ... % +1
                stateUtility(ntk+2,trialsSinceCashout,8,1),... % +2
                stateUtility(ntk-1,trialsSinceCashout,8,1),... % -1
                stateUtility(ntk-2,trialsSinceCashout,8,1)]; % -2
            FEV_single_choice= gamma*(dot(transitPsFutureStates,utilitiesFutureStates));
            actionvalues(choice)=FEV_single_choice;
        end
        %actionvalues
            %beta=3;

            %old code to fit one beta for one condition but fix others
%             if condition==1
%                 beta=beta2v1;
%             else
%                 beta=betaRW;
%             end

            beta=beta_all;

            d = exp(beta*actionvalues)./sum(exp(beta*actionvalues));
            if condition==1
                dt(condition,nobs) = d(2);
            else
                dt(condition,nobs) = d(1); %choice prob for option 1
            end
    end

end


%take difference between dt and monkey behavior:
diffMDP_CP_and_behavior=[];
err=[];
for c=1:6
    pcorrSingleCondition(:,:)=pcorr_allFiles(:,c,:);
    pcorr_mean=nanmean(pcorrSingleCondition);
    pcorr_mean(isnan(pcorr_mean))=[];

    err(c,:)=dt(c,:)-pcorr_mean; %difference between model CP and avg monkey choice data
end

%minimize the rmse error:
rmse=sqrt(sum(sum(err.^2))/length(pcorr_mean));

