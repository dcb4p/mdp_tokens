function [dt,vt,chodt,chovt,llt] = tkexprlevalalg(params,cho,rew,blk,cond)
%  
% 
% 
% 
% 
vcho = [1 2 3 4];
vint = [0 0 0 0];
 
ll = 0;
beta1 = params(1);
bigR = params(2);
smR = params(3);
bigP = params(4);
smP = params(5); 

dt = zeros(size(cho,1),2); 
vt = zeros(size(cho,1),4); 
chodt = zeros(size(cho,1),1); 
chovt = zeros(size(cho,1),1);
llt = zeros(size(cho,1),1);
 
for t = 1:size(cho,1)
    
    %initialize values for first and block reset 
    if t==1
        v = vint;
    elseif blk(t,1)~=blk(t-1,1)
        v = vint;
    end;
    
    tcho = cho(t,1);
    vt(t,:) = v;
    chovt(t,1) = v(tcho);
    trew = rew(t,1);
    tcond = cond(t,1); 
    
    
    if tcond == 1
        kn = logical([1 1 0 0]);
        d = exp(beta1*v(kn))./sum(exp(beta1*v(kn)));
        dcho = vcho(kn);
        chod = d(dcho==tcho);
   elseif tcond == 2
        kn = logical([1 0 1 0]); 
        d = exp(beta1*v(kn))./sum(exp(beta1*v(kn)));
        dcho = vcho(kn);
        chod = d(dcho==tcho);
    elseif tcond == 3 
        kn = logical([0 1 1 0]); 
        d = exp(beta1*v(kn))./sum(exp(beta1*v(kn)));
        dcho = vcho(kn);
        chod = d(dcho==tcho);
   elseif tcond == 4
        kn = logical([1 0 0 1]); 
        d = exp(beta1*v(kn))./sum(exp(beta1*v(kn)));
        dcho = vcho(kn);
        chod = d(dcho==tcho);
   elseif tcond == 5 
        kn = logical([0 1 0 1]); 
        d = exp(beta1*v(kn))./sum(exp(beta1*v(kn)));
        dcho = vcho(kn);
        chod = d(dcho==tcho);
    elseif tcond == 6 
        kn = logical([0 0 1 1]); 
        d = exp(beta1*v(kn))./sum(exp(beta1*v(kn)));
        dcho = vcho(kn);
        chod = d(dcho==tcho);
    end   
    
    dt(t,:) = d;
    %chod = d(tcho);
    chodt(t,1) = chod;
    
%      if tcond == 6
%         ll = ll; 
%     else 
%         ll = ll-log(chod);
%      end
%     
    ll = ll - log(chod);  
    llt(t,1) = ll;
    
    
    if trew == 2
        v(tcho) = v(tcho) + bigR*(trew - v(tcho));
    elseif trew == 1
        v(tcho) = v(tcho) + smR*(trew - v(tcho));
    elseif trew == -1 
        v(tcho) = v(tcho) + smP*(trew - v(tcho)); 
    elseif trew == -2 
        v(tcho) = v(tcho) + bigP*(trew - v(tcho));
    elseif trew == -4 %big loss in TkL  
        v(tcho) = v(tcho) + bigP*(trew - v(tcho));
    end
    
end

