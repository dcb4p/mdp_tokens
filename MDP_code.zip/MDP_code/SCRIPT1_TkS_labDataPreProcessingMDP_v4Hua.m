%TkS_labDataPreProcessingMDP_v4Hua.m
%last edit DCB: 04.21.2023
%for data formatted as a giant matrix for a single monkey (TkS)
%data INCLUDES abort trials (diff than v1) and familiar and novel

%extracts:
%(1) behavioral performance
%(2) RW fits (rlfitkexpM11.m)
%(3) value curves from RW fits
% Input: single monkey data in format listed in comments below. all sessions. assumes familiar blocks are 10/11/12
% Output: 2 files: ...dataForMDP.mat and ...RWfits_Modell11.mat


%This is step (1) of the MDP model generation process
% (1) Fit RW, get curve fits
% (2) Optimize MDP parameters for posterior prob
% (3) Fit MDP using these new parameters and value curves
% (4) Run all you favorite regressions on behavioral data, fit gamma

clear

 monkey='Uno';
% monkey='Boom';
%  monkey='Prima'
%  monkey='Sparkles';
% monkey='AJacks';
% monkey='CardiB';
%monkey='Blis';

if strcmp(monkey,'Uno')
    load('UnoMatrix_v3_withAborts.mat')
elseif strcmp(monkey,'Boom')
    load('BoomDatamat.mat')
elseif strcmp(monkey,'Prima')
    load('PrimaDatamat.mat')
elseif strcmp(monkey,'Sparkles')
    load('SparklesDatamat.mat')
elseif strcmp(monkey,'AJacks')
    %load('AppleJacks_20sessions.mat')
    load('AppleJacks_version2.mat')
elseif strcmp(monkey,'CardiB')
    load('CardiB.mat')
elseif strcmp(monkey,'Blis')
    load('Blis.mat')
end

monkeydata=data;

plotSingleSession=0; %option to plot single session of behavior (for troubleshooting)
FITRWMODEL=1; %option to fit RW model, if 0, will not fit model

% C1 = Session trl number
% C2= Block number
% C3= Trial error: (0=good tr, 4=no fix, 3= broke fix, 5= did not select cue, 6= did not hold selected cue)
% C4 = Condition (including side) – 700
% 1 & 2 = 2 v 1
% 3 & 4 = 1 v -1
% 5 & 6 = 2 v -1
% 7 & 8 = 1 v -2
% 9 & 10 = 2 v -2
% 11 & 12 = -1 v -2
% C5 = Not important for this
% C6 = Cue selected (including side) – 500
% 	14 & 15 = +1 cue
% 	16 & 17 = +2 cue
% 	18 & 19 = -1 cue
% 	20 & 21 = -2 cue
% C7:C8 = not important for this
% C9 = trl since cashout – 33
% C10 = tokens on before choice – 800
% C11 = tokens on after choice – 900
% C12 = Cue selected (no side)
% 	1 = +1 cue
% 	2 = +2 cue
% 	3 = -1 cue
% 	4 = -2 cue
% C13 = Change in tokens after choice
% C14 = Session
% C15 = Condition (no side)
% 1= 2 v 1
% 2 = 1 v -1
% 3 = 2 v -1
% 4 = 1 v -2
% 5 = 2 v -2
% 6 = -1 v -2
% C18 = n/a
% C20 = time of event code 20 (fixation on)
% C22 = time of event code 21 (fixation off)
% C24 = time of event code 40 (cue on) (identical to fixation off)
% C26 = time of event code 41 (choice)

%all sessions, all data (including aborts and familiar blocks):
sessions=monkeydata(:,14);
nsessions=length(unique(sessions));
%reactiontimes=monkeydata(:,18);

%getting reaction times for acquiring fixation and choice:
RT_acquirefix= monkeydata(:,22)-monkeydata(:,20); %currently includes hold time, whatever that is, this won't work if that time is variable on every trial
reactiontimes=monkeydata(:,26)-monkeydata(:,24); %currently includes hold time, whatever that is
RT_choice=reactiontimes;
blocknum=monkeydata(:,2);


%RECODE NaN values to be tsco for that trial:
tsco=monkeydata(:,9)-33+ 1; %1->6 and NaNs for aborts
for i=1:length(tsco)
    if isnan(tsco(i))
        x=1;
        %find next non NaN value in tsco
        while isnan(tsco(i+x))
            %keep going
            x=x+1;
        end
        next_tsco_val=tsco(i+x);
        tsco(i)=next_tsco_val;
    else
    end
end
monkeydata(:,9)=tsco;

%RECODE NaN values to be tk before choice:
currTkBeforeChoice=monkeydata(:,10)-800;
for i=1:length(currTkBeforeChoice)
    if isnan(currTkBeforeChoice(i))
        x=1;
        %find next non NaN value in tsco
        while isnan(currTkBeforeChoice(i+x))
            %keep going
            x=x+1;
        end
        next_currtk_val=currTkBeforeChoice(i+x);
        currTkBeforeChoice(i)=next_currtk_val;
    else
    end
end
monkeydata(:,10)=currTkBeforeChoice;

%NOTE: Change in Tk after choice left as NaN for abort trials since there was no choice
outcomes=monkeydata(:,13);
tkChangeAfterChoice=monkeydata(:,13); %-2,-1,0,1,2
totalTkAfterTrial=currTkBeforeChoice+tkChangeAfterChoice; %BEFORE CASHOUTS (So on cashout trials, this value will be n tokens received)


condition=monkeydata(:,15);
% 1= 2 v 1
% 2 = 1 v -1
% 3 = 2 v -1
% 4 = 1 v -2
% 5 = 2 v -2
% 6 = -1 v -2
choice=monkeydata(:,12); %1= +1 cue, 2= +2 cue, 3= -1 cue, 4= -2 cue



%% Collect behavioral data for single session of completed novel blocks of trials, option to plot, fit RW model


sessionIDs=unique(sessions);

for sss=1:length(sessionIDs)
    singlesession=sessionIDs(sss)

    clearvars -except monkey monkeydata singlesession pcorr_allFiles mRT_allFiles numObs_allFiles ...
        modelParams_allFiles modelLL_allFiles modelChoiceProb_allFiles modelValueEstimates_allFiles modelMeanCueValues_allFiles ...
        plotSingleSession  sessions nsessions reactiontimes trials blocknum tsco currTkBeforeChoice tkChangeAfterChoice totalTkAfterTrial...
        outcomes condition choice tkChangeAfterChoice FITRWMODEL RT_acquirefix sessionIDs sss chovt_allFiles ...
        modelMeanCueValues_54_allFiles


    %for one session, all blocks, ~*only*~ completed trials of novel blocks !! :
    ntr=length(find(sessions==singlesession & monkeydata(:,3)==0 & blocknum ~=10  & blocknum ~=11  & blocknum ~=12 ));

    completedtrials=find(sessions==singlesession & monkeydata(:,3)==0 & blocknum ~=10  & blocknum ~=11  & blocknum ~=12 );
    blocknumber=blocknum(completedtrials);


    nblocks=length(unique(blocknumber));
    blocks=unique(blocknumber);
   
    conditionID= condition(completedtrials);
    choiceIDs= choice(completedtrials);
    choiceVals=choiceIDs;
    choiceVals(find(choiceVals==3))=-1;
    choiceVals(find(choiceVals==4))=-2;
    rts=reactiontimes(completedtrials);
    reward=outcomes(completedtrials);

    choiceMatrix= nan(6,nblocks,18);
    rtMatrix= nan(6,nblocks,18);
    clearvars choices rtsAllBlocks trialByTrialPCorr trialByTrialmeanRT trialByTrialRT_stderr
    condit6={'2v1','1v -1','2 v -1','1 v -2','2 v -2','-1 v -2'};
    for c=1:6
        for b=1:nblocks

            singleBlock=blocks(b);
            singleConditionBothSides= find( conditionID==c & blocknumber==singleBlock);
            chosenValues=choiceVals(singleConditionBothSides);
            reactionTimes=rts(singleConditionBothSides);

            possibleVals=sort(unique(chosenValues));
            largerOptionValue=max(possibleVals);

            %recode choices as 0s and 1s depending on picking larger option
            tmp=zeros(1,length(chosenValues));
            tmp(find(chosenValues==largerOptionValue))=1;
            choiceMatrix(c,b,1:length(chosenValues))=tmp;
            rtMatrix(c,b,1:length(chosenValues))=reactionTimes;
        end

        %calculate average chosen lg option across blocks:
        choices(:,:)=choiceMatrix(c,:,:);
        trialByTrialPCorr(c,:)=nanmean(choices);

        rtsAllBlocks=rtMatrix(c,:,:);
        trialByTrialmeanRT(c,:)=nanmean(rtsAllBlocks);
        trialByTrialRT_stderr(c,:)=nanstd(rtsAllBlocks)/sqrt(size(rtsAllBlocks,2));

        %plot single session?
        if plotSingleSession==1
            %individual file plots, average across blocks:
            nb=length(trialByTrialPCorr);

            figure(singlesession+100)
            set(gcf,'Color',[1 1 1])
            subplot(2,6,c)
            plot(1:nb,trialByTrialPCorr(c,:),'o-','LineWidth',1.5); hold on
            set(gca,'fontsize',14)
            xlabel('Trial number')
            title(condit6(c))
            ylabel('Fraction larger option (or juice) chosen')
            ylim([0.5,1])

            set(gcf,'Color',[1 1 1])
            subplot(2,6,c+6)
            plot(1:nb,trialByTrialmeanRT(c,:),'mo-','LineWidth',1.5); hold on
            errorbar(1:nb,trialByTrialmeanRT(c,:),trialByTrialRT_stderr(c,:),'m')
            set(gca,'fontsize',14)
            xlabel('Trial number')
            title(condit6(c))
            ylabel('Mean RT')
            ylim([100 300])
            sgtitle(strcat('Stochastic-PCorr & RTs, average of',{' '},num2str(nblocks),{' '},'blocks'))
        end
    end


    %% Fit RW model to single session:

    if FITRWMODEL==1
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        allmparams = zeros(30,7); %30 iterations
        cho = choiceIDs;
        rew = reward;
        blk = blocknumber;
        cond = conditionID;
        nparams=5;

        parfor m = 1:30
            %disp(m);
            %starting values for parameters:

            params = rand(1) * 5;
            params(2:5) = rand(1,4);
            % beta1 = params(1);
            % bigR = params(2);
            % smR = params(3);
            % bigP = params(4); %learning rate for lg loss -2
            % smP = params(5); %learning rate for small loss -1

            options = optimset('MaxFunEvals', 10000, 'TolFun', 0.00001,'MaxIter',10000,'Display','off');

            %fit params:

            %ADDED DB 1.11.2023: bound learning rates to be positive values:
            LB=[-inf 0 0 0 0];
            UB=[inf inf inf inf inf];
            %bounded:
            [mparams, lla, exitflag] = fminsearchbnd(@(params) tkexprlfitalg(params,cho,rew, blk, cond), params, LB,UB, options);

            %original unbounded:
            %[mparams, lla, exitflag] = fminsearch(@(params) tkexprlfitalg(params,cho,rew,blk,cond),params, options);

            %save across iterations:
            allmparams(m,:) = [mparams lla exitflag];
        end

        goodexits = sum(allmparams(:,7) == 1);
        noext = ('failed');

        if goodexits < 1
            keep = allmparams(allmparams(:,7)==0,:);
            keep = sortrows(keep,[6]);
            mparams = keep(1,1:5);
            lla = keep(1,6);
            exitflag = keep(1,7);
            display(ii);
            display(noext);
        else
            keep = allmparams(allmparams(:,7)==1,:);
            keep = sortrows(keep,[6]);
            mparams = keep(1,1:5);
            lla = keep(1,6);
            exitflag = keep(1,7);
        end

        mparamsbest=mparams;

        [dt,vt,chodt,chovt,llt] = tkexprlevalalg(mparamsbest,cho,rew,blk,cond);
        %close all;
        %figure;
        %plot(dt);
        %vals{singlesession} = [dt,vt,chodt,chovt,llt];
        %bestmparm(singlesession,:) = [mparamsbest,lla,exitflag,blksum,singlesession];
        %d will by trial x only 2 choices available on that given trial
        %v will be trial x all 4 choice options (1= +1 2= +2 3= -1 4= -2)

        if plotSingleSession==1
            figure(singlesession + 300)
            set(gcf,'color',[1 1 1])
            plot(vt(:,1)); hold on; plot(vt(:,2)); plot(vt(:,3)); plot(vt(:,4));
            xlabel('Trial'); ylabel('Model Value estimate'); legend('+1','+2','-1','-2')
            title('Model value estimates for 4 options')

            %model value estimate of best option for +2v+1 trials:
                %tmp=vt(find(cond==1),1:2)
                %plot(tmp(1:18,1)); hold on; plot(tmp(1:18,2))

        end

        %% Get average values for 4 options from model fit across entire session to save across sessions (fig 2)
        %maybe don't want this across blocks in this way, but rather by condition (also saved in the next block)
        clearvars tmp_vals tmp_cond
        numCorrectTrialsPerBlock=108; %change this if task changed
        blks=unique(blk);
        tmp_vals=nan(4,length(blks),numCorrectTrialsPerBlock);
        tmp_cond=nan(length(blks),numCorrectTrialsPerBlock);

        for bbb=1:length(blks)
            trs=find(blk==blks(bbb));
            for val=1:4
                tmp_vals(val,bbb,1:length(trs))=vt(trs,val)'; %accounts for partial blocks
            end
            tmp_cond(bbb,:) =cond(trs); 
        end


            for cue=1:4
                mean_model_vals(cue,:)=nanmean(tmp_vals(cue,:,:));
                %figure(654); set(gcf,'Color',[1 1 1]); plot(1:length(mean_model_vals),mean_model_vals(cue,:),'o-'); hold on
            end
            %xlabel('Trial in block'); ylabel('Mean cue value, model estimate'); legend('+1','+2','-1','-2')
       

        %****new Figure 2B part 1 for paper: For each cue, plot only the 54 observations of that cue, plot the
        %value whether or not it was chosen: need to use cond here to pull
        %trials: 
        %cue 1: +1 (cond 1,2,4)
        %cue 2: +2 (cond 1,3,5)
        %cue 3: -1 (cond 2,3,6)
        %cue 4: -2 (cond 4,5,6)

        cuecondit=[ 1,2,4; 1,3,5; 2,3,6; 4,5,6];
        tmp_vals_54= nan(4,length(blks),54);
        for cue=1:4
            %tmp_vals= 4 cues x n blocks x 108 in order
            %tmp_cond = nblocks x 108 in order
            relevantconditions=cuecondit(cue,:);
            for bbb=1:length(blks)
                trs=find(tmp_cond(bbb,:)==relevantconditions(1) | tmp_cond(bbb,:)==relevantconditions(2) | tmp_cond(bbb,:)==relevantconditions(3));
                tmp_vals_54(cue,bbb,:)=tmp_vals(cue,bbb,trs);
            end
        end

        %Now plot average across blocks of 1->54 times for each cue:
        for cue=1:4
            mean_model_cuevals_54(cue,:)=nanmean(tmp_vals_54(cue,:,:));
            %figure(654); set(gcf,'Color',[1 1 1]); plot(1:length(mean_model_cuevals_54),mean_model_cuevals_54(cue,:),'o-','MarkerFaceColor','k','LineWidth',2); hold on
        end
        %xlabel('Number of times cue was shown'); ylabel('Mean cue value, model estimate'); legend('+1','+2','-1','-2')

        %%%%%%%%%%%%% save this across sessions to get 1 session from
        %%%%%%%%%%%%% monkey U later 1/2024




        %% Save chovt (chosen value) across sessions to use in regressions (replies to reviewers) ::

        if sss==1
            %initialize: 
            chovt_allFiles= {}; %structure because diff sessions have diff # of blocks
        end

        if FITRWMODEL==1
            chovt_allFiles{sss}=chovt;
        end

        %% Save trial by trial averages: pcorr & rts (across blocks), avg model outputs: values & choiceprob (across blocks), and params, for combining across sessions
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % trialByTrialPCorr trialByTrialmeanRT are already 6x18 by condition. Do the same for the model data:

        trialByTrialModelValueEstimates=nan(6,18,2);
        trialByTrialModelChoiceProb=nan(6,18,2);

        for cc=1:6

            %conditions:
            % 1= 2 v 1
            % 2 = 1 v -1
            % 3 = 2 v -1
            % 4 = 1 v -2
            % 5 = 2 v -2
            % 6 = -1 v -2
            %vector [+1 +2 -1 -2]:
            if cc == 1
                kn = logical([1 1 0 0]); %'2 v 1'
            elseif cc == 2
                kn = logical([1 0 1 0]); %'1 v -1'
            elseif cc == 3
                kn = logical([0 1 1 0]); %'2 v -1'
            elseif cc == 4
                kn = logical([1 0 0 1]); %'1 v -2'
            elseif cc == 5
                kn = logical([0 1 0 1]); %'2 v -2'
            elseif cc == 6
                kn = logical([0 0 1 1]); %'-1 v -2'
            end

            modelblocks=blks;

            tmpD=nan(length(modelblocks),18,2); %max number of trials per condition= 18, hard coded here, change if block length is longer than 108
            tmpV=nan(length(modelblocks),18,2);

            for bb=1:length(modelblocks)

                trs=find(cond==cc & blk==modelblocks(bb));

                choiceprob=dt(trs,:);

                estimval=vt(trs,:);
                relevantVals=repmat(kn,length(trs),1);
                estimval=estimval(:,kn);

                %to handle partially completed blocks:
                if size(estimval,1) < 18
                    tmpD(bb,1:size(estimval,1),:)=choiceprob;
                    tmpV(bb,1:size(estimval,1),:)=estimval;
                else
                    tmpD(bb,:,:)=choiceprob;
                    tmpV(bb,:,:)=estimval;
                end
            end

            %Average across blocks to save by condition:

            trialByTrialModelValueEstimates(cc,:,:)=nanmean(tmpV);
            trialByTrialModelChoiceProb(cc,:,:)=nanmean(tmpD);

        end

        %collect value estimates for each of 4 options and average across conditions:
        %6 conditions x 2 for side
        % 1= 1 v 2   (best= opt 2)
        % 2 = 1 v -1 (best= opt 1 in all other cases)
        % 3 = 2 v -1
        % 4 = 1 v -2
        % 5 = 2 v -2
        % 6 = -1 v -2

        ntrialsPerCondition=18;
        meanCueValues=nan(4,ntrialsPerCondition);
        for cue=1:4
            if cue==1 %+1
                %collect 3 conditions each cue is in and which option
                t1(:,:)=trialByTrialModelValueEstimates(1,:,1);
                t2(:,:)=trialByTrialModelValueEstimates(2,:,1);
                t3(:,:)=trialByTrialModelValueEstimates(4,:,1);

            elseif cue==2 %+2
                t1(:,:)=trialByTrialModelValueEstimates(1,:,2);
                t2(:,:)=trialByTrialModelValueEstimates(3,:,1);
                t3(:,:)=trialByTrialModelValueEstimates(5,:,1);

            elseif cue==3 % -1
                %maybe only use condition 6 here??
                t1(:,:)=trialByTrialModelValueEstimates(2,:,2);
                t2(:,:)=trialByTrialModelValueEstimates(3,:,2);
                t3(:,:)=trialByTrialModelValueEstimates(6,:,1);
            elseif cue==4 % -2
                %maybe only use condition 6 here??
                t1(:,:)=trialByTrialModelValueEstimates(4,:,2);
                t2(:,:)=trialByTrialModelValueEstimates(5,:,2);
                t3(:,:)=trialByTrialModelValueEstimates(6,:,2);
            end
            meanCueValues(cue,:)=nanmean([t1;t2;t3]);


        end

    end
       
        %% Saving across all sessions:
        nconditions=6;
        ntrialsPerCondition=18;

        if sss==1
            %initialize
            pcorr_allFiles=nan(nsessions,nconditions, ntrialsPerCondition);
            mRT_allFiles=nan(nsessions,nconditions, ntrialsPerCondition);
            numObs_allFiles=nan(nsessions,1);

            if FITRWMODEL==1
                modelParams_allFiles=nan(nsessions,nparams);
                modelLL_allFiles=nan(nsessions,1);
                modelChoiceProb_allFiles=nan(nsessions,nconditions, ntrialsPerCondition,2);
                modelValueEstimates_allFiles=nan(nsessions,nconditions, ntrialsPerCondition,2);

                %to keep track of mean value estimates by time, not condition, was observed:
                modelMeanCueValues_allFiles=nan(nsessions,4, ntrialsPerCondition);

                %average RW cue value each time the cue was shown (1.2024):
                modelMeanCueValues_54_allFiles=nan(nsessions,4, 54);

            end
        end

        pcorr_allFiles(sss,:,:)=trialByTrialPCorr;
        mRT_allFiles(sss,:,:)=trialByTrialmeanRT;
        numObs_allFiles(sss)=length(blocknumber); %number of trials in an entire session

        if FITRWMODEL==1
            modelParams_allFiles(sss,:)=mparamsbest;
            modelLL_allFiles(sss,1)=lla;
            modelChoiceProb_allFiles(sss,:,:,:)=trialByTrialModelChoiceProb;
            modelValueEstimates_allFiles(sss,:,:,:)=trialByTrialModelValueEstimates;

            modelMeanCueValues_allFiles(sss,:,:)=meanCueValues;

            modelMeanCueValues_54_allFiles(sss,:,:)=mean_model_cuevals_54;
        end


end

%% %%%% ~~~~~~~~~ End of looping over sessions for PCorr & RW ~~~~~~~~~~~~~~ %%%%


%% Save all data across all files:

formatOut = 'mm_dd_yy';
mdy=datestr(now,formatOut);
CHOOSEMODEL=11;
if FITRWMODEL==1
     fname=strcat(mdy,'_',monkey,'_TkS_loss_RWfits_Model',num2str(CHOOSEMODEL),'.mat');

else
     fname=strcat(mdy,'_',monkey,'_TkS_loss_AbortAnalysis.mat');

end

save(fname)

%% Save chosen values in separate file alone:

%restructure to one giant list:
nf=size(chovt_allFiles,2);

chosenVals_allFilesConcat=[];
trialcount=0;

for n=1:nf

    %trialcount=trialcount+length(chovt_allFiles{1,nf})

    chovt_tmp=chovt_allFiles{1,n};

    chosenVals_allFilesConcat=[chosenVals_allFilesConcat;chovt_tmp];

end

save(strcat(monkey,'_chosenValueData.mat'),'chovt_allFiles','chosenVals_allFilesConcat')

%% save just mean cue values for MDP

fname=strcat(mdy,'_monkey_',monkey,'_DataForMDP.mat');
save(fname,'ntrialsPerCondition','modelMeanCueValues_allFiles')


%% Plotting behavior and RW fits across all sessions:

plotcol='r';



for c= 1:6
%for c= 6

    pcorrSingleCondition(:,:)=pcorr_allFiles(:,c,:);
    mRTSingleCondition(:,:)=mRT_allFiles(:,c,:);


    pcorr_mean=nanmean(pcorrSingleCondition);
    pcorr_mean(isnan(pcorr_mean))=[];
    pcorr_stderr=stderr(pcorrSingleCondition);
    pcorr_stderr(isnan(pcorr_stderr))=[];


    rt_mean=nanmean(mRTSingleCondition);
    rt_mean(isnan(rt_mean))=[];
    rt_stderr=stderr(mRTSingleCondition);
    rt_stderr(isnan(rt_stderr))=[];

    figure(1)
    %avg performance
    set(gcf,'Color',[1 1 1])
    %subplot(2,6,c)
    plot(1:length(pcorr_mean),pcorr_mean,'ko-','LineWidth',1.5); hold on
    errorbar(1:length(pcorr_mean),pcorr_mean,pcorr_stderr,'k')
    set(gca,'fontsize',14)
    xlabel('Trial')
    title(condit6(c))
    if c==1
        ylabel('Fraction larger opt chosen')
    end
    xlim([0 18]); ylim([0.4 1])


    %avg reaction times
    figure(1)
    %subplot(2,6,c+6)
    plot(1:length(rt_mean),rt_mean,'mo-','LineWidth',1.5); hold on
    errorbar(1:length(rt_mean),rt_mean,rt_stderr,'m')
    set(gca,'fontsize',14)
    xlabel('Trial')
    ylabel('Mean RT')
    sgtitle(strcat('TkS-PCorr & Mean RTs ',{' '},'monkey=',monkey,{' '},'(nSessions=',{' '},num2str(nsessions),')'))
    xlim([0 18])
    %ylim([150 220])
    set(gca,'fontsize',14)

    %Choice Probability as predicted by model:
    %better option happens to be the first in all cases:

    if c==1
        betterOpt=2;
    else
        betterOpt=1;
    end

    cp(:,:)=modelChoiceProb_allFiles(:,c,:,betterOpt);
    meanCP=nanmean(cp);
    stderrCP=stderr(cp);
    figure(1)
    %model choice probability overlayed
    set(gcf,'Color',[1 1 1])
    %subplot(2,6,c)
    plot(1:length(meanCP),meanCP,'Color',plotcol,'LineStyle','-','Marker','o', ...
        'LineWidth',1.5); hold on
    errorbar(1:length(meanCP),meanCP,stderrCP,'Color',plotcol)


%     figure(2)
%     %avg performance
%     set(gcf,'Color',[1 1 1])
%     subplot(2,3,c)
%     plot(1:length(pcorr_mean),pcorr_mean,'ko-','LineWidth',1.5); hold on
%     errorbar(1:length(pcorr_mean),pcorr_mean,pcorr_stderr,'k')
%     plot(1:length(meanCP),meanCP,'Color',plotcol,'LineStyle','-','Marker','o', ...
%         'LineWidth',1.5); hold on
%     errorbar(1:length(meanCP),meanCP,stderrCP,'Color',plotcol)
%     set(gca,'fontsize',14)
%     xlabel('Trial')
%     title(condit6(c))
%     if c==1
%         ylabel('Fraction larger opt chosen')
%     end
%     xlim([0 18]); ylim([0.4 1])

%     figure(3)
%     %rts separate
%      %avg reaction times
%      set(gcf,'Color',[1 1 1])
%     subplot(2,3,c)
%     plot(1:length(rt_mean),rt_mean,'go-','LineWidth',1.5); hold on
%     errorbar(1:length(rt_mean),rt_mean,rt_stderr,'g')
%     set(gca,'fontsize',14)
%     xlabel('Trial')
%     ylabel('Mean RT')
%     sgtitle(strcat('Mean RTs ',{' '},'monkey=',monkey,{' '},'(nSessions=',{' '},num2str(nsessions),')'))
%     xlim([0 18])
%     %ylim([220 260])
%     set(gca,'fontsize',14)


end



