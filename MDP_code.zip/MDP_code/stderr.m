function [out]=stderr(in)

out=(std(in))/sqrt(length(in));